<?php
/**
 * prepara_boleto_pp.php — Interceptor central do assinante
 * Se o título tem boleto PagoraPay ativo → abre boleto.php (PIX + Boleto moderno)
 * Caso contrário → passa para prepara_boleto.hhvm original
 */

// Evita loop: se veio com bypass, deixa o .hhvm processar
if (isset($_GET['pp_bypass'])) {
    // Não deve chegar aqui, mas por segurança
    header('Location: /central/prepara_boleto.hhvm?' . http_build_query(array_merge($_GET, ['pp_bypass'=>'1'])));
    exit;
}

$uuid = $_GET['titulo'] ?? '';
if (!$uuid) {
    header('Location: /central/prepara_boleto.hhvm?' . http_build_query(array_merge($_GET, ['pp_bypass'=>'1'])));
    exit;
}

// Conecta ao banco
$db = new mysqli('127.0.0.1', 'root', 'vertrigo', 'mkradius');
if ($db->connect_error) {
    header('Location: /central/prepara_boleto.hhvm?' . http_build_query(array_merge($_GET, ['pp_bypass'=>'1'])));
    exit;
}

// Resolve UUID → id
$stmt = $db->prepare("SELECT id FROM sis_lanc WHERE uuid_lanc = ? LIMIT 1");
$stmt->bind_param('s', $uuid);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$row) {
    header('Location: /central/prepara_boleto.hhvm?' . http_build_query(array_merge($_GET, ['pp_bypass'=>'1'])));
    exit;
}

$titulo_id = intval($row['id']);

// Verifica se existe boleto PagoraPay ativo
$stmt2 = $db->prepare(
    "SELECT id FROM pagorapay_boletos WHERE titulo_id = ? AND status NOT IN ('cancelado','erro') LIMIT 1"
);
$stmt2->bind_param('i', $titulo_id);
$stmt2->execute();
$boleto = $stmt2->get_result()->fetch_assoc();
$stmt2->close();
$db->close();

if ($boleto) {
    // Tem boleto PagoraPay → abre página moderna com PIX
    header('Location: /admin/addons/pagorapay/boleto_print_central.php?titulo_id=' . $titulo_id);
} else {
    // Sem boleto PagoraPay → passa para o original
    header('Location: /central/prepara_boleto.hhvm?' . http_build_query(array_merge($_GET, ['pp_bypass'=>'1'])));
}
exit;
