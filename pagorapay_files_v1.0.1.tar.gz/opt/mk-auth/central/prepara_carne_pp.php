<?php
$codigo_carne = $_GET['carne'] ?? '';
if (!$codigo_carne) {
    header('Location: /central/prepara_carne.hhvm?' . http_build_query($_GET));
    exit;
}

$db = new mysqli('127.0.0.1', 'root', 'vertrigo', 'mkradius');
if ($db->connect_error) {
    header('Location: /central/prepara_carne.hhvm?' . http_build_query(array_merge($_GET, ['pp_bypass'=>'1'])));
    exit;
}

// Verifica se algum boleto do carnê tem PagoraPay ativo
$codigo = $db->real_escape_string($codigo_carne);
$res = $db->query("SELECT pb.id FROM pagorapay_boletos pb
    JOIN sis_lanc l ON l.id = pb.carne_id
    WHERE l.codigo_carne = '$codigo' AND pb.status NOT IN ('cancelado','erro')
    LIMIT 1");
$boleto = $res ? $res->fetch_assoc() : null;
$db->close();

if ($boleto) {
    header('Location: /admin/addons/pagorapay/carne_print_central.php?carne=' . urlencode($codigo_carne));
} else {
    header('Location: /central/prepara_carne.hhvm?' . http_build_query(array_merge($_GET, ['pp_bypass'=>'1'])));
}
exit;
