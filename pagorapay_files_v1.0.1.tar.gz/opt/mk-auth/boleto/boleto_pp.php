<?php
$titulo_id = intval($_GET['titulo'] ?? 0);
if (!$titulo_id) {
    header('Location: /boleto/boleto.hhvm?' . http_build_query($_GET));
    exit;
}

$db = new mysqli('127.0.0.1', 'root', 'vertrigo', 'mkradius');
if ($db->connect_error) {
    header('Location: /boleto/boleto.hhvm?' . http_build_query(array_merge($_GET, ['pp_bypass'=>'1'])));
    exit;
}

$stmt = $db->prepare("SELECT id FROM pagorapay_boletos WHERE titulo_id = ? AND status NOT IN ('cancelado','erro') LIMIT 1");
$stmt->bind_param('i', $titulo_id);
$stmt->execute();
$boleto = $stmt->get_result()->fetch_assoc();
$stmt->close();
$db->close();

if ($boleto) {
    header('Location: /admin/addons/pagorapay/boleto_print_central.php?titulo_id=' . $titulo_id);
} else {
    header('Location: /boleto/boleto.hhvm?' . http_build_query(array_merge($_GET, ['pp_bypass'=>'1'])));
}
exit;
