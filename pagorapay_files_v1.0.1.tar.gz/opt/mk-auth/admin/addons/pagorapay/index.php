<?php
/**
 * Addon PagoraPay para MKAuth 22+
 * index.php — Interface principal
 */

session_start();
require_once __DIR__ . '/config.php';

$config_ok  = !empty($PAGORAPAY['api_key']);
$action     = $_GET['action'] ?? 'lista';
$msg        = $_SESSION['msg'] ?? '';
$msg_type   = $_SESSION['msg_type'] ?? 'info';
unset($_SESSION['msg'], $_SESSION['msg_type']);

// ── AÇÕES POST ────────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pa = $_POST['action'] ?? '';

    if ($pa === 'salvar_config') {
        $cfg = pagorapay_get_config();

        $nova_key = trim($_POST['api_key'] ?? '');
        if (!empty($nova_key)) $cfg['api_key'] = $nova_key;

        $cfg['sandbox']         = isset($_POST['sandbox']);
        $cfg['dias_vencimento'] = intval($_POST['dias_vencimento'] ?? 3);
        $cfg['multa']           = floatval($_POST['multa'] ?? 2.0);
        $cfg['juros']           = floatval($_POST['juros'] ?? 1.0);
        $cfg['instrucoes']      = trim($_POST['instrucoes'] ?? '');
        $cfg['numconta']        = intval($_POST['numconta'] ?? 0);

        if (empty($cfg['webhook_token'])) {
            $cfg['webhook_token'] = md5(uniqid('mkauth_pagorapay_', true));
        }

        pagorapay_save_config($cfg);
        $PAGORAPAY = $cfg;
        $config_ok = !empty($cfg['api_key']);

        $_SESSION['msg']      = '✅ Configurações salvas com sucesso!';
        $_SESSION['msg_type'] = 'success';
        header('Location: index.php?action=config');
        exit;
    }

    if ($pa === 'emitir_boleto') {
        require_once __DIR__ . '/boleto_api.php';
        $resultado = pagorapay_emitir_boleto($_POST);
        $_SESSION['msg']      = $resultado['msg'];
        $_SESSION['msg_type'] = $resultado['success'] ? 'success' : 'danger';
        if ($resultado['success'] && !empty($resultado['link_pagamento'])) {
            $_SESSION['link_pagamento'] = $resultado['link_pagamento'];
        }
        header('Location: index.php?action=lista');
        exit;
    }

    if ($pa === 'cancelar_boleto') {
        require_once __DIR__ . '/boleto_api.php';
        $resultado = pagorapay_cancelar_boleto($_POST['id_externo'], (int)$_POST['registro_id']);
        $_SESSION['msg']      = $resultado['msg'];
        $_SESSION['msg_type'] = $resultado['success'] ? 'success' : 'danger';
        header('Location: index.php?action=lista');
        exit;
    }

    if ($pa === 'sincronizar') {
        require_once __DIR__ . '/boleto_api.php';
        $id_externo = $_POST['id_externo'] ?? '';
        $res_api    = pagorapay_consultar_status($id_externo);
        if ($res_api['success']) {
            $st      = strtolower($res_api['data']['dados']['status'] ?? '');
            $st_map  = ['pago' => 'pago', 'aguardando' => 'pendente', 'cancelado' => 'cancelado'];
            $novo_st = $st_map[$st] ?? 'pendente';
            $ie_safe = $LOADMYSQL->real_escape_string($id_externo);
            $LOADMYSQL->query("UPDATE pagorapay_boletos SET status='$novo_st', updated_at=NOW() WHERE id_externo='$ie_safe'");
            $_SESSION['msg']      = "🔄 Status atualizado para: $novo_st";
            $_SESSION['msg_type'] = 'info';
        } else {
            $_SESSION['msg']      = "❌ Erro: " . ($res_api['data']['mensagem'] ?? 'Erro desconhecido');
            $_SESSION['msg_type'] = 'danger';
        }
        header('Location: index.php?action=lista');
        exit;
    }
}

// ── GARANTE TABELA ────────────────────────────────────────────────────────────
$LOADMYSQL->query("CREATE TABLE IF NOT EXISTS pagorapay_boletos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id VARCHAR(20),
    cliente_nome VARCHAR(150),
    carne_id VARCHAR(50),
    id_externo VARCHAR(80),
    boleto_id VARCHAR(100),
    boleto_url TEXT,
    link_pagamento TEXT,
    pix_copia_cola TEXT,
    pix_qrcode TEXT,
    valor DECIMAL(10,2),
    valor_liquido DECIMAL(10,2),
    vencimento DATE,
    status VARCHAR(20) DEFAULT 'pendente',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_cliente (cliente_id),
    INDEX idx_id_externo (id_externo),
    INDEX idx_carne (carne_id),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// ── DADOS ─────────────────────────────────────────────────────────────────────
$boletos = [];
$res_b = $LOADMYSQL->query("SELECT * FROM pagorapay_boletos ORDER BY created_at DESC LIMIT 200");
if ($res_b) while ($r = $res_b->fetch_assoc()) $boletos[] = $r;

// Clientes ativos para nova cobrança
$clientes = [];
if ($action === 'novo') {
    $res_cli = $LOADMYSQL->query("SELECT id, login, nome, cpf_cnpj, email, celular
                                   FROM sis_cliente WHERE cli_ativado='s'
                                   ORDER BY nome ASC LIMIT 2000");
    if ($res_cli) while ($c = $res_cli->fetch_assoc()) $clientes[] = $c;
}

// Contas cadastradas no MKAuth para o select de configuração
$contas_mkauth = [];
$res_contas = $LOADMYSQL->query("SELECT id, nome FROM sis_boleto ORDER BY nome ASC");
if ($res_contas) while ($c = $res_contas->fetch_assoc()) $contas_mkauth[] = $c;

// AJAX: títulos em aberto do cliente
if (isset($_GET['get_carnes'])) {
    $login_safe = $LOADMYSQL->real_escape_string($_GET['get_carnes']);
    $numconta   = intval($PAGORAPAY['numconta'] ?? 0);
    $where_conta = $numconta ? "AND l.numconta=$numconta" : '';
    $res_t = $LOADMYSQL->query("SELECT l.id, l.obs as descricao, l.valor, l.datavenc as vencimento, l.login
                                 FROM sis_lanc l
                                 WHERE l.login='$login_safe'
                                 AND l.status='aberto'
                                 $where_conta
                                 ORDER BY l.datavenc ASC LIMIT 50");
    $titulos = [];
    if ($res_t) while ($t = $res_t->fetch_assoc()) $titulos[] = $t;
    header('Content-Type: application/json');
    echo json_encode($titulos);
    exit;
}

// URLs
$base_url     = (isset($_SERVER['HTTPS']) ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];
$webhook_url  = $base_url . '/admin/addons/pagorapay/webhook.php?token=' . ($PAGORAPAY['webhook_token'] ?? '');
$webhook_mkauth = $base_url . '/admin/addons/pagorapay/webhook_mkauth.php?token=' . ($PAGORAPAY['webhook_token'] ?? '');

// Totais
$total_pendente = count(array_filter($boletos, fn($b) => $b['status'] === 'pendente'));
$total_pago     = count(array_filter($boletos, fn($b) => $b['status'] === 'pago'));
$valor_pago     = array_sum(array_column(array_filter($boletos, fn($b) => $b['status'] === 'pago'), 'valor'));

$chave_salva   = $PAGORAPAY['api_key'] ?? '';
$chave_mascara = !empty($chave_salva)
    ? substr($chave_salva, 0, 10) . '...' . substr($chave_salva, -6) : '';
$link_gerado   = $_SESSION['link_pagamento'] ?? '';
unset($_SESSION['link_pagamento']);

// Conta selecionada
$numconta_atual = intval($PAGORAPAY['numconta'] ?? 0);
$conta_nome     = '';
foreach ($contas_mkauth as $c) {
    if ($c['id'] == $numconta_atual) { $conta_nome = $c['nome']; break; }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>PagoraPay | MKAuth</title>
<style>
* { box-sizing:border-box; }
body { font-family:Arial,sans-serif; background:#f4f6f8; margin:0; padding:16px; color:#333; }
.card { background:#fff; border-radius:8px; box-shadow:0 1px 4px rgba(0,0,0,.1); padding:20px; margin-bottom:16px; }
.card-header { display:flex; justify-content:space-between; align-items:center; margin-bottom:16px; padding-bottom:12px; border-bottom:1px solid #eee; }
h2 { margin:0; font-size:1.15rem; color:#2c3e50; }
h3 { font-size:1rem; color:#555; margin:0 0 12px 0; }
.btn { display:inline-block; padding:7px 16px; border-radius:5px; text-decoration:none; font-size:.88rem; border:none; cursor:pointer; font-weight:600; }
.btn-primary   { background:#2980b9; color:#fff; }
.btn-success   { background:#27ae60; color:#fff; }
.btn-danger    { background:#e74c3c; color:#fff; }
.btn-secondary { background:#95a5a6; color:#fff; }
.btn-info      { background:#17a2b8; color:#fff; }
.btn:hover { opacity:.85; }
.alert { padding:11px 16px; border-radius:5px; margin-bottom:14px; font-size:.92rem; }
.alert-success { background:#d4edda; color:#155724; border:1px solid #c3e6cb; }
.alert-danger  { background:#f8d7da; color:#721c24; border:1px solid #f5c6cb; }
.alert-info    { background:#d1ecf1; color:#0c5460; border:1px solid #bee5eb; }
.alert-warning { background:#fff3cd; color:#856404; border:1px solid #ffc107; }
table { width:100%; border-collapse:collapse; font-size:.88rem; }
th,td { padding:8px 12px; text-align:left; border-bottom:1px solid #eee; }
th { background:#f8f9fa; font-weight:700; color:#555; }
tr:hover { background:#fafafa; }
.badge { display:inline-block; padding:2px 9px; border-radius:12px; font-size:.76rem; font-weight:700; }
.badge-success   { background:#d4edda; color:#155724; }
.badge-warning   { background:#fff3cd; color:#856404; }
.badge-secondary { background:#e2e3e5; color:#383d41; }
label { display:block; margin-bottom:4px; font-size:.87rem; font-weight:600; color:#555; }
input[type=text],input[type=number],input[type=date],select,textarea {
  width:100%; padding:8px 10px; border:1px solid #ccc; border-radius:5px; font-size:.9rem; margin-bottom:12px;
}
input:focus,select:focus { border-color:#2980b9; outline:none; }
.form-row   { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
.form-row-3 { display:grid; grid-template-columns:1fr 1fr 1fr; gap:16px; }
.tabs { display:flex; gap:4px; margin-bottom:18px; border-bottom:2px solid #e0e0e0; }
.tab { padding:8px 18px; border-radius:6px 6px 0 0; font-size:.9rem; text-decoration:none; color:#555; background:#f0f0f0; }
.tab.active { background:#2980b9; color:#fff; }
.stats-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:12px; margin-bottom:16px; }
.stat-card  { background:#fff; border-radius:8px; padding:16px; text-align:center; border-left:4px solid #ccc; }
.stat-card.verde   { border-color:#27ae60; }
.stat-card.azul    { border-color:#2980b9; }
.stat-card.laranja { border-color:#f39c12; }
.stat-number { font-size:1.8rem; font-weight:700; margin:4px 0; }
.stat-label  { font-size:.82rem; color:#888; }
.chave-ok { background:#d4edda; border:1px solid #c3e6cb; border-radius:5px; padding:8px 12px; margin-bottom:8px; font-size:.88rem; color:#155724; }
.code-box { background:#f8f9fa; padding:10px 12px; border-radius:5px; font-size:.83rem; word-break:break-all; border:1px solid #e0e0e0; margin-bottom:12px; position:relative; }
.btn-copy { position:absolute; right:8px; top:8px; background:#2980b9; color:#fff; border:none; border-radius:4px; padding:3px 9px; font-size:.76rem; cursor:pointer; }
.btn-copy:hover { background:#2471a3; }
.section-box { border:1px solid #e0e0e0; border-radius:6px; padding:16px; margin-bottom:16px; }
.section-box h4 { margin:0 0 12px 0; font-size:.92rem; color:#2c3e50; border-bottom:1px solid #eee; padding-bottom:8px; }
.step { display:flex; gap:10px; margin-bottom:10px; align-items:flex-start; font-size:.88rem; }
.step-num { background:#2980b9; color:#fff; border-radius:50%; width:22px; height:22px; display:flex; align-items:center; justify-content:center; font-weight:700; font-size:.78rem; flex-shrink:0; margin-top:1px; }
.conta-badge { display:inline-block; background:#d4edda; color:#155724; border-radius:4px; padding:2px 10px; font-size:.82rem; font-weight:700; }
.aviso-config { background:#fff3cd; border:1px solid #ffc107; border-radius:6px; padding:10px 14px; font-size:.87rem; color:#856404; margin-bottom:14px; }
@media(max-width:600px){ .form-row,.form-row-3,.stats-grid{ grid-template-columns:1fr; } }
</style>
</head>
<body>

<div class="card">
  <div class="card-header">
    <h2>💳 PagoraPay — Boleto &amp; PIX</h2>
    <div>
      <a href="index.php?action=config" class="btn btn-secondary">⚙️ Configurações</a>
      <?php if ($config_ok): ?>
        <a href="index.php?action=novo" class="btn btn-primary" style="margin-left:6px;">+ Nova Cobrança</a>
      <?php endif; ?>
    </div>
  </div>

  <div class="tabs">
    <a href="index.php?action=lista"  class="tab <?= $action==='lista' ?'active':'' ?>">📋 Cobranças</a>
    <a href="index.php?action=novo"   class="tab <?= $action==='novo'  ?'active':'' ?>">➕ Nova Cobrança</a>
    <a href="index.php?action=config" class="tab <?= $action==='config'?'active':'' ?>">⚙️ Configurações</a>
  </div>

  <?php if ($msg): ?>
    <div class="alert alert-<?= htmlspecialchars($msg_type) ?>"><?= htmlspecialchars($msg) ?></div>
  <?php endif; ?>
  <?php if ($link_gerado): ?>
    <div class="alert alert-success">✅ Cobrança gerada! <a href="<?= htmlspecialchars($link_gerado) ?>" target="_blank"><strong>🔗 Acessar link de pagamento</strong></a></div>
  <?php endif; ?>
  <?php if (!$config_ok && $action !== 'config'): ?>
    <div class="alert alert-warning">⚠️ Configure sua API Key antes de emitir. <a href="index.php?action=config">Configurar agora</a>.</div>
  <?php endif; ?>
</div>

<?php if ($action === 'lista'): ?>
<!-- ═══════════════════════════════════════════════ LISTA -->
<div class="stats-grid">
  <div class="stat-card azul">
    <div class="stat-number"><?= $total_pendente ?></div>
    <div class="stat-label">Aguardando Pagamento</div>
  </div>
  <div class="stat-card verde">
    <div class="stat-number"><?= $total_pago ?></div>
    <div class="stat-label">Pagas</div>
  </div>
  <div class="stat-card laranja">
    <div class="stat-number">R$ <?= number_format($valor_pago,2,',','.') ?></div>
    <div class="stat-label">Total Recebido</div>
  </div>
</div>
<div class="card">
  <?php if (empty($boletos)): ?>
    <p style="text-align:center;color:#888;padding:30px 0;">Nenhuma cobrança emitida ainda.</p>
  <?php else: ?>
  <table>
    <thead>
      <tr><th>Cliente</th><th>Valor</th><th>Vencimento</th><th>Status</th><th>Emitido em</th><th>Ações</th></tr>
    </thead>
    <tbody>
      <?php foreach ($boletos as $b):
        $badge = match($b['status']) { 'pago'=>'badge-success','pendente'=>'badge-warning',default=>'badge-secondary' };
        $label = match($b['status']) { 'pago'=>'✅ Pago','pendente'=>'⏳ Aguardando','cancelado'=>'❌ Cancelado',default=>ucfirst($b['status']) };
      ?>
      <tr>
        <td><strong><?= htmlspecialchars($b['cliente_nome']) ?></strong><br><small style="color:#888"><?= htmlspecialchars($b['id_externo']) ?></small></td>
        <td><strong>R$ <?= number_format($b['valor'],2,',','.') ?></strong></td>
        <td><?= date('d/m/Y', strtotime($b['vencimento'])) ?></td>
        <td><span class="badge <?= $badge ?>"><?= $label ?></span></td>
        <td><?= date('d/m/Y H:i', strtotime($b['created_at'])) ?></td>
        <td style="white-space:nowrap">
          <?php if (!empty($b['link_pagamento'])): ?>
            <a href="<?= htmlspecialchars($b['link_pagamento']) ?>" target="_blank" class="btn btn-primary" style="font-size:.76rem;padding:4px 9px;">🔗 Pagar</a>
          <?php endif; ?>
          <?php if ($b['status'] === 'pendente'): ?>
            <form method="POST" style="display:inline;">
              <input type="hidden" name="action" value="sincronizar">
              <input type="hidden" name="id_externo" value="<?= htmlspecialchars($b['id_externo']) ?>">
              <button class="btn btn-info" style="font-size:.76rem;padding:4px 9px;" title="Sincronizar status">🔄</button>
            </form>
            <form method="POST" style="display:inline;" onsubmit="return confirm('Cancelar esta cobrança?')">
              <input type="hidden" name="action" value="cancelar_boleto">
              <input type="hidden" name="id_externo" value="<?= htmlspecialchars($b['id_externo']) ?>">
              <input type="hidden" name="registro_id" value="<?= $b['id'] ?>">
              <button class="btn btn-danger" style="font-size:.76rem;padding:4px 9px;" title="Cancelar">❌</button>
            </form>
          <?php endif; ?>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
  <?php endif; ?>
</div>

<?php elseif ($action === 'novo'): ?>
<!-- ═══════════════════════════════════════════════ NOVA COBRANÇA -->
<div class="card">
  <h2 style="margin-bottom:16px;">➕ Nova Cobrança (Boleto + PIX)</h2>
  <?php if (!$config_ok): ?>
    <div class="alert alert-warning">Configure a API Key antes. <a href="index.php?action=config">Configurar</a>.</div>
  <?php else: ?>
  <form method="POST">
    <input type="hidden" name="action" value="emitir_boleto">
    <div class="form-row">
      <div>
        <label>Cliente *</label>
        <select name="cliente_id" id="sel_cliente" required onchange="buscarTitulos(this)">
          <option value="">-- Selecione o cliente --</option>
          <?php foreach ($clientes as $c): ?>
            <option value="<?= htmlspecialchars($c['id']) ?>"
              data-login="<?= htmlspecialchars($c['login']) ?>"
              data-cpf="<?= htmlspecialchars(preg_replace('/\D/','',$c['cpf_cnpj']??'')) ?>">
              <?= htmlspecialchars($c['nome']) ?> (<?= htmlspecialchars($c['login']) ?>)
              <?php if (empty($c['cpf_cnpj'])): ?> ⚠️<?php endif; ?>
            </option>
          <?php endforeach; ?>
        </select>
        <div id="aviso_cpf" class="alert alert-warning" style="display:none">⚠️ Cliente sem CPF/CNPJ. Atualize o cadastro.</div>
      </div>
      <div>
        <label>Título Vinculado (opcional)</label>
        <select name="titulo_id" id="sel_titulo">
          <option value="">-- Cobrança avulsa --</option>
        </select>
      </div>
    </div>
    <div class="form-row">
      <div>
        <label>Valor (R$) * — mínimo R$ 5,00</label>
        <input type="text" name="valor" id="inp_valor" placeholder="Ex: 89,90" required>
      </div>
      <div>
        <label>Data de Vencimento *</label>
        <input type="date" name="vencimento" id="inp_vencimento" required
          value="<?= date('Y-m-d', strtotime('+' . $PAGORAPAY['dias_vencimento'] . ' days')) ?>">
      </div>
    </div>
    <div>
      <label>Descrição (aparece no boleto)</label>
      <input type="text" name="descricao" value="<?= htmlspecialchars($PAGORAPAY['instrucoes']) ?>" placeholder="Ex: Mensalidade Internet <?= date('m/Y') ?>">
    </div>
    <div style="margin-top:8px;">
      <button type="submit" class="btn btn-success" style="padding:10px 28px;font-size:.95rem;">💳 Gerar Cobrança (Boleto + PIX)</button>
      <a href="index.php?action=lista" class="btn btn-secondary" style="margin-left:8px;">Cancelar</a>
    </div>
  </form>
  <?php endif; ?>
</div>

<?php elseif ($action === 'config'): ?>
<!-- ═══════════════════════════════════════════════ CONFIGURAÇÕES -->
<div class="card">
  <h2 style="margin-bottom:16px;">⚙️ Configurações PagoraPay</h2>
  <form method="POST">
    <input type="hidden" name="action" value="salvar_config">

    <!-- ── API KEY ── -->
    <div class="section-box">
      <h4>🔑 Credenciais da API</h4>
      <div>
        <label>API Key PagoraPay * <small style="font-weight:normal;color:#888">(Painel PagoraPay → API &amp; Integrações → Chaves API)</small></label>
        <?php if (!empty($chave_mascara)): ?>
          <div class="chave-ok">✅ Chave configurada: <code><?= htmlspecialchars($chave_mascara) ?></code> — Deixe em branco para manter.</div>
        <?php endif; ?>
        <input type="text" name="api_key" value="" placeholder="<?= !empty($chave_salva) ? 'Deixe em branco para manter' : 'pp_xxxxxxxxxxxxxxxx...' ?>" autocomplete="off">
        <small style="color:#888;">Começa com <code>pp_</code>. Não há API Secret — somente esta chave.</small>
      </div>
      <div style="margin-top:8px;">
        <label>
          <input type="checkbox" name="sandbox" <?= ($PAGORAPAY['sandbox'] ?? false) ? 'checked' : '' ?>>
          Ambiente Sandbox (Testes) — desmarque para produção
        </label>
      </div>
    </div>

    <!-- ── CONTA MKAUTH ── -->
    <div class="section-box">
      <h4>🏦 Conta no MKAuth</h4>
      <p style="font-size:.87rem;color:#666;margin-bottom:12px;">
        Selecione a conta cadastrada em <strong>Provedor → Controle de Contas</strong> que representa a PagoraPay.
        Isso vincula os títulos gerados por esta conta ao addon para baixa automática.
      </p>
      <div>
        <label>Conta PagoraPay no MKAuth</label>
        <select name="numconta">
          <option value="0">-- Não vincular (cobranças avulsas) --</option>
          <?php foreach ($contas_mkauth as $c): ?>
            <option value="<?= $c['id'] ?>" <?= ($c['id'] == $numconta_atual) ? 'selected' : '' ?>>
              #<?= $c['id'] ?> — <?= htmlspecialchars($c['nome']) ?>
            </option>
          <?php endforeach; ?>
        </select>
        <?php if ($numconta_atual && $conta_nome): ?>
          <small style="color:#27ae60;">✅ Vinculada: <strong><?= htmlspecialchars($conta_nome) ?></strong> (ID <?= $numconta_atual ?>)</small>
        <?php else: ?>
          <small style="color:#888;">Títulos desta conta aparecerão automaticamente ao selecionar um cliente na aba Nova Cobrança.</small>
        <?php endif; ?>
      </div>
    </div>

    <!-- ── BOLETO ── -->
    <div class="section-box">
      <h4>📄 Configurações Padrão do Boleto</h4>
      <div class="form-row-3">
        <div>
          <label>Dias para Vencimento</label>
          <input type="number" name="dias_vencimento" value="<?= intval($PAGORAPAY['dias_vencimento']) ?>" min="1" max="60">
        </div>
        <div>
          <label>Multa por Atraso (%)</label>
          <input type="number" name="multa" value="<?= $PAGORAPAY['multa'] ?>" step="0.01" min="0" max="10">
        </div>
        <div>
          <label>Juros ao Mês (%)</label>
          <input type="number" name="juros" value="<?= $PAGORAPAY['juros'] ?>" step="0.01" min="0" max="5">
        </div>
      </div>
      <div>
        <label>Descrição Padrão (aparece no boleto)</label>
        <input type="text" name="instrucoes" value="<?= htmlspecialchars($PAGORAPAY['instrucoes']) ?>" placeholder="Ex: Mensalidade Internet">
      </div>
    </div>

    <!-- ── WEBHOOKS ── -->
    <div class="section-box">
      <h4>🔗 Webhooks</h4>

      <label>1. Webhook PagoraPay → MKAuth <small style="font-weight:normal;color:#888">(pagamento confirmado — quita título automaticamente)</small></label>
      <div class="code-box">
        <span id="wh1"><?= htmlspecialchars($webhook_url) ?></span>
        <button type="button" class="btn-copy" onclick="copiar('wh1',this)">Copiar</button>
      </div>
      <div class="aviso-config">
        📌 Cole esta URL em: <strong>Painel PagoraPay → API &amp; Integrações → Chaves API → ícone Webhook</strong>
      </div>

      <label>2. Webhook MKAuth → PagoraPay <small style="font-weight:normal;color:#888">(ao gerar carnê/título — emite automaticamente)</small></label>
      <div class="code-box">
        <span id="wh2"><?= htmlspecialchars($webhook_mkauth) ?></span>
        <button type="button" class="btn-copy" onclick="copiar('wh2',this)">Copiar</button>
      </div>
      <div class="aviso-config">
        📌 Cole esta URL em: <strong>MKAuth → Provedor → DEV → Webhook do usuário</strong>
      </div>

      <?php if (empty($PAGORAPAY['webhook_token'])): ?>
        <div class="alert alert-warning">⚠️ Salve as configurações para gerar o token do webhook.</div>
      <?php else: ?>
        <small style="color:#888;">Token: <code><?= htmlspecialchars($PAGORAPAY['webhook_token']) ?></code></small>
      <?php endif; ?>
    </div>

    <button type="submit" class="btn btn-success" style="padding:10px 24px;font-size:.95rem;">💾 Salvar Configurações</button>
  </form>
</div>
<?php endif; ?>

<script>
function buscarTitulos(sel) {
  const opt   = sel.options[sel.selectedIndex];
  const cpf   = opt?.dataset.cpf  || '';
  const login = opt?.dataset.login || '';
  const aviso = document.getElementById('aviso_cpf');
  const selT  = document.getElementById('sel_titulo');

  aviso.style.display = (sel.value && !cpf) ? 'block' : 'none';

  if (!login) { selT.innerHTML = '<option value="">-- Cobrança avulsa --</option>'; return; }

  selT.innerHTML = '<option>Carregando...</option>';
  fetch('index.php?get_carnes=' + encodeURIComponent(login))
    .then(r => r.json())
    .then(data => {
      selT.innerHTML = '<option value="">-- Cobrança avulsa --</option>';
      if (!data.length) { selT.innerHTML += '<option disabled>Nenhum título em aberto</option>'; return; }
      data.forEach(t => {
        const o = document.createElement('option');
        o.value = t.id;
        const vf = parseFloat(t.valor).toFixed(2).replace('.', ',');
        o.textContent = `${t.descricao || 'Título'} — R$ ${vf} — Venc: ${t.vencimento}`;
        o.dataset.valor = t.valor;
        o.dataset.venc  = t.vencimento ? t.vencimento.substring(0,10) : '';
        selT.appendChild(o);
      });
    })
    .catch(() => { selT.innerHTML = '<option value="">Erro ao buscar</option>'; });
}

document.getElementById('sel_titulo')?.addEventListener('change', function() {
  const o = this.options[this.selectedIndex];
  if (o.dataset.valor) {
    document.getElementById('inp_valor').value      = parseFloat(o.dataset.valor).toFixed(2).replace('.', ',');
    document.getElementById('inp_vencimento').value = o.dataset.venc;
  }
});

function copiar(spanId, btn) {
  const txt = document.getElementById(spanId).textContent.trim();
  navigator.clipboard?.writeText(txt).then(() => {
    const orig = btn.textContent;
    btn.textContent = '✅ Copiado!';
    setTimeout(() => btn.textContent = orig, 2000);
  });
}
</script>
</body>
</html>
