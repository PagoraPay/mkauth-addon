<?php
if (!defined('PAGORAPAY_API_URL')) {
    require_once __DIR__ . '/config.php';
}

// ── Garante estrutura da tabela ───────────────────────────────────────────────
$LOADMYSQL->query("CREATE TABLE IF NOT EXISTS pagorapay_boletos (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id      VARCHAR(20),
    cliente_nome    VARCHAR(150),
    carne_id        VARCHAR(50),
    titulo_id       INT(11),
    id_externo      VARCHAR(80),
    boleto_id       VARCHAR(100),
    boleto_url      TEXT,
    link_pagamento  TEXT,
    pix_copia_cola  TEXT,
    pix_qrcode      TEXT,
    linha_digitavel VARCHAR(100),
    codigo_barras   VARCHAR(100),
    valor           DECIMAL(10,2),
    valor_liquido   DECIMAL(10,2),
    vencimento      DATE,
    status          VARCHAR(20) DEFAULT 'pendente',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_cliente    (cliente_id),
    INDEX idx_id_externo (id_externo),
    INDEX idx_carne      (carne_id),
    INDEX idx_titulo     (titulo_id),
    INDEX idx_status     (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Migração segura: adiciona colunas que podem faltar em instalações antigas
$LOADMYSQL->query("ALTER TABLE pagorapay_boletos ADD COLUMN IF NOT EXISTS carne_id        VARCHAR(50)  AFTER cliente_nome");
$LOADMYSQL->query("ALTER TABLE pagorapay_boletos ADD COLUMN IF NOT EXISTS titulo_id       INT(11)      AFTER carne_id");
$LOADMYSQL->query("ALTER TABLE pagorapay_boletos ADD COLUMN IF NOT EXISTS linha_digitavel VARCHAR(100) AFTER pix_qrcode");
$LOADMYSQL->query("ALTER TABLE pagorapay_boletos ADD COLUMN IF NOT EXISTS codigo_barras   VARCHAR(100) AFTER linha_digitavel");
$LOADMYSQL->query("ALTER TABLE pagorapay_boletos ADD INDEX IF NOT EXISTS idx_titulo (titulo_id)");

// ── Emite cobrança na PagoraPay e salva no banco ──────────────────────────────
function pagorapay_emitir_boleto(array $post): array {
    global $LOADMYSQL, $PAGORAPAY;

    $cliente_id = $LOADMYSQL->real_escape_string($post['cliente_id'] ?? '');
    $valor      = is_numeric($post['valor'] ?? '') && strpos((string)($post['valor']), ',') === false
                    ? round((float)($post['valor']), 2)
                    : pagorapay_valor_float($post['valor'] ?? '0');
    $vencimento = $post['vencimento'] ?? '';
    $titulo_id  = $post['titulo_id']  ?? null;
    $referencia = trim($post['referencia'] ?? '');
    $descricao  = trim($post['descricao']  ?? $PAGORAPAY['instrucoes'] ?? '');

    // Monta descrição com referência do mês
    if (!empty($referencia) && strpos($descricao, $referencia) === false) {
        $descricao = $descricao ? "$descricao - $referencia" : $referencia;
    }
    if (empty($descricao)) $descricao = 'Mensalidade Internet';

    if (empty($cliente_id)) return ['success' => false, 'msg' => 'Selecione um cliente.'];
    if ($valor < 5.00)      return ['success' => false, 'msg' => 'Valor mínimo é R$ 5,00 (exigência PagoraPay).'];
    if (empty($vencimento)) return ['success' => false, 'msg' => 'Data de vencimento obrigatória.'];

    $res = $LOADMYSQL->query("SELECT id, nome, login, cpf_cnpj, email, celular FROM sis_cliente WHERE id='$cliente_id' LIMIT 1");
    if (!$res || $res->num_rows === 0) return ['success' => false, 'msg' => 'Cliente não encontrado.'];
    $cli = $res->fetch_assoc();

    $cpf_cnpj = pagorapay_only_numbers($cli['cpf_cnpj'] ?? '');
    if (empty($cpf_cnpj)) return ['success' => false, 'msg' => 'Cliente sem CPF/CNPJ. Atualize o cadastro.'];

    // Idempotência: verifica se já existe boleto ativo para este título
    if (!empty($titulo_id)) {
        $tid_check = intval($titulo_id);
        $res_dup = $LOADMYSQL->query("SELECT id FROM pagorapay_boletos WHERE carne_id='$tid_check' AND status NOT IN ('cancelado','erro') LIMIT 1");
        if ($res_dup && $res_dup->num_rows > 0) {
            return ['success' => false, 'msg' => "⚠️ Já existe cobrança ativa para o título #$titulo_id."];
        }
    }

    $id_externo  = 'mk_' . $cliente_id . '_' . time();
    $nome_partes = explode(' ', trim($cli['nome']));
    $primeiro    = array_shift($nome_partes);
    $sobrenome   = implode(' ', $nome_partes);

    $payload = [
        'nome'       => $primeiro,
        'sobrenome'  => $sobrenome,
        'cpf_cnpj'   => $cpf_cnpj,
        'valor'      => $valor,
        'vencimento' => $vencimento,
        'id_externo' => $id_externo,
        'descricao'  => $descricao,
        'multa'      => (float)($PAGORAPAY['multa'] ?? 2),
        'juros'      => (float)($PAGORAPAY['juros'] ?? 1),
    ];
    if (!empty($cli['email']))   $payload['email']   = $cli['email'];
    if (!empty($cli['celular'])) $payload['celular']  = pagorapay_only_numbers($cli['celular']);

    $response = pagorapay_request('POST', '/erp/gerar_cobranca.php', $payload);

    if (!$response['success']) {
        $erro = $response['data']['mensagem'] ?? 'Erro desconhecido';
        return ['success' => false, 'msg' => "❌ Erro PagoraPay: $erro"];
    }

    $dados           = $response['data']['dados'] ?? [];
    $boleto_id       = (string)($dados['id_transacao'] ?? $dados['id_pagorapay'] ?? '');
    $link_pagamento  = $dados['link_pagamento']  ?? '';
    $boleto_url      = $dados['link_boleto']     ?? $link_pagamento;
    $pix_copia_cola  = $dados['pix_copia_cola']  ?? '';
    $pix_qrcode      = $dados['pix_qrcode']      ?? '';
    $valor_liquido   = (float)($dados['valor_liquido'] ?? $valor);
    $linha_digitavel = $dados['linha_digitavel'] ?? '';
    $codigo_barras   = $dados['codigo_barras']   ?? '';

    $ci   = $LOADMYSQL->real_escape_string($cliente_id);
    $cn   = $LOADMYSQL->real_escape_string($cli['nome']);
    $cid  = intval($titulo_id ?: 0);
    $ie   = $LOADMYSQL->real_escape_string($id_externo);
    $bi   = $LOADMYSQL->real_escape_string($boleto_id);
    $bu   = $LOADMYSQL->real_escape_string($boleto_url);
    $lp   = $LOADMYSQL->real_escape_string($link_pagamento);
    $pc   = $LOADMYSQL->real_escape_string($pix_copia_cola);
    $pq   = $LOADMYSQL->real_escape_string($pix_qrcode);
    $ve   = $LOADMYSQL->real_escape_string($vencimento);
    $ld   = $LOADMYSQL->real_escape_string($linha_digitavel);
    $cb   = $LOADMYSQL->real_escape_string($codigo_barras);

    $sql = "INSERT INTO pagorapay_boletos
            (cliente_id, cliente_nome, carne_id, titulo_id, id_externo, boleto_id,
             boleto_url, link_pagamento, pix_copia_cola, pix_qrcode,
             linha_digitavel, codigo_barras,
             valor, valor_liquido, vencimento, status)
            VALUES ('$ci','$cn'," . ($cid ?: 'NULL') . "," . ($cid ?: 'NULL') . ",'$ie','$bi',
                    '$bu','$lp','$pc','$pq','$ld','$cb',
                    $valor, $valor_liquido, '$ve', 'pendente')";

    if (!$LOADMYSQL->query($sql)) {
        return ['success' => false, 'msg' => 'Erro ao salvar: ' . $LOADMYSQL->error];
    }

    // ── Integração nativa com MKAuth ─────────────────────────────────────────
    if (!empty($titulo_id)) {
        $tid = intval($titulo_id);

        // 1. Atualiza linhadig, codigo_barras e url no sis_lanc
        if ($linha_digitavel || $codigo_barras || $link_pagamento) {
            $ld_s  = $LOADMYSQL->real_escape_string($linha_digitavel);
            $cb_s  = $LOADMYSQL->real_escape_string($codigo_barras);
            $url_s = $LOADMYSQL->real_escape_string($link_pagamento ?: $boleto_url);
            $LOADMYSQL->query("UPDATE sis_lanc SET
                linhadig      = IF('$ld_s' != '', '$ld_s', linhadig),
                codigo_barras = IF('$cb_s' != '', '$cb_s', codigo_barras),
                url           = IF('$url_s' != '', '$url_s', url)
                WHERE id = $tid");
        }

        // 2. Insere QR code PIX em sis_qrpix (chave = nossonum do título)
        if ($pix_copia_cola) {
            $res_nn = $LOADMYSQL->query("SELECT nossonum FROM sis_lanc WHERE id=$tid LIMIT 1");
            if ($res_nn && $row_nn = $res_nn->fetch_assoc()) {
                $nn  = $LOADMYSQL->real_escape_string($row_nn['nossonum']);
                $pix = $LOADMYSQL->real_escape_string($pix_copia_cola);
                $LOADMYSQL->query("INSERT INTO sis_qrpix (titulo, qrcode)
                    VALUES ('$nn', '$pix')
                    ON DUPLICATE KEY UPDATE qrcode='$pix'");
            }
        }
    }

    return [
        'success'        => true,
        'msg'            => "✅ Cobrança gerada para {$cli['nome']}! Valor líquido: R$ " . number_format($valor_liquido, 2, ',', '.'),
        'link_pagamento' => $link_pagamento,
        'boleto_url'     => $boleto_url,
    ];
}

// ── Cancela cobrança na PagoraPay ─────────────────────────────────────────────
function pagorapay_cancelar_boleto(string $id_externo, int $registro_id): array {
    global $LOADMYSQL;
    $response = pagorapay_request('POST', '/erp/cancelar_cobranca.php', ['id_externo' => $id_externo]);
    if ($response['success']) {
        $LOADMYSQL->query("UPDATE pagorapay_boletos SET status='cancelado', updated_at=NOW() WHERE id=$registro_id");
        return ['success' => true, 'msg' => '✅ Cobrança cancelada.'];
    }
    // Se já estava cancelada na PagoraPay, atualiza local também
    $msg_api = strtolower($response['data']['mensagem'] ?? '');
    if (strpos($msg_api, 'cancelado') !== false || strpos($msg_api, 'cancelada') !== false) {
        $LOADMYSQL->query("UPDATE pagorapay_boletos SET status='cancelado', updated_at=NOW() WHERE id=$registro_id");
        return ['success' => true, 'msg' => '✅ Cobrança já estava cancelada na PagoraPay — atualizado localmente.'];
    }
    return ['success' => false, 'msg' => '❌ ' . ($response['data']['mensagem'] ?? 'Erro ao cancelar')];
}

// ── Consulta status de cobrança na PagoraPay ──────────────────────────────────
function pagorapay_consultar_status(string $id_externo): array {
    return pagorapay_request('GET', '/erp/consultar_cobranca.php?id_externo=' . urlencode($id_externo));
}
