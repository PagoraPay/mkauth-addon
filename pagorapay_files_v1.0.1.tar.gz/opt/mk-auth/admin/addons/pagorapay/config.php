<?php
require_once '/opt/mk-auth/include/conexao.php';

define('PAGORAPAY_CONFIG_FILE', __DIR__ . '/pagorapay_config.json');

function pagorapay_get_config() {
    if (file_exists(PAGORAPAY_CONFIG_FILE)) {
        $json = file_get_contents(PAGORAPAY_CONFIG_FILE);
        $cfg  = json_decode($json, true);
        if (is_array($cfg)) return $cfg;
    }
    return [
        'api_key'          => '',
        'sandbox'          => false,
        'dias_vencimento'  => 3,
        'multa'            => 2.0,
        'juros'            => 1.0,
        'instrucoes'       => 'Mensalidade Internet',
        'webhook_token'    => md5(uniqid('mkauth_pagorapay_', true)),
        'numconta'         => 0,
    ];
}

function pagorapay_save_config($config) {
    file_put_contents(PAGORAPAY_CONFIG_FILE, json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// Valida token de webhook — aceita comparação simples
function pagorapay_validar_token($token) {
    global $PAGORAPAY;
    $esperado = $PAGORAPAY['webhook_token'] ?? '';
    return !empty($token) && !empty($esperado) && $token === $esperado;
}

$PAGORAPAY = pagorapay_get_config();

define('PAGORAPAY_API_URL', 'https://pagorapay.com.br/api/v1');

function pagorapay_request($method, $endpoint, $data = []) {
    global $PAGORAPAY;
    $url     = PAGORAPAY_API_URL . $endpoint;
    $headers = [
        'Content-Type: application/json',
        'Accept: application/json',
        'Authorization: Bearer ' . $PAGORAPAY['api_key'],
    ];
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL            => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_CUSTOMREQUEST  => strtoupper($method),
    ]);
    if (in_array(strtoupper($method), ['POST', 'PUT']) && !empty($data)) {
        if (isset($data['valor'])) {
            $data['valor'] = round((float)$data['valor'], 2);
        }
        $json_payload = json_encode($data);
        file_put_contents('/tmp/pp_payload.log', date('H:i:s') . ' ' . $json_payload . "\n", FILE_APPEND);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $json_payload);
    }
    $response  = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curl_err  = curl_error($ch);
    curl_close($ch);

    if ($curl_err) {
        return ['success' => false, 'data' => ['sucesso' => false, 'mensagem' => $curl_err], 'http_code' => 0];
    }
    $decoded = json_decode($response, true);
    $sucesso  = ($decoded['sucesso'] ?? false) === true;
    return [
        'success'   => $sucesso,
        'data'      => $decoded ?? ['sucesso' => false, 'mensagem' => $response],
        'http_code' => $http_code,
    ];
}

function pagorapay_only_numbers($value) {
    return preg_replace('/\D/', '', $value ?? '');
}

function pagorapay_valor_float($value) {
    $v = str_replace('.', '', $value ?? '0');
    $v = str_replace(',', '.', $v);
    return round(floatval($v), 2);
}
