<?php
$raw = file_get_contents('php://input');
$headers = getallheaders();
file_put_contents('/tmp/webhook_carne_debug.txt', 
    '['.date('Y-m-d H:i:s').']'."\n".
    'HEADERS: '.json_encode($headers)."\n".
    'PAYLOAD: '.$raw."\n\n", 
    FILE_APPEND|LOCK_EX);
http_response_code(200);
echo 'ok';
