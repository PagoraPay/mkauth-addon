<?php
// Central do assinante - sem autenticação admin
$db = new mysqli('127.0.0.1', 'root', 'vertrigo', 'mkradius');
if ($db->connect_error) die('<p style="color:red">Erro de conexão.</p>');
$LOADMYSQL = $db;

$codigo_carne = $_GET['carne'] ?? '';
if (!$codigo_carne) die('Código do carnê não informado.');
$sql = "SELECT l.nossonum, l.linhadig as linha_mk,
               pb.linha_digitavel as pp_linha,
               pb.pix_copia_cola, pb.pix_qrcode, pb.boleto_url
        FROM sis_lanc l
        LEFT JOIN pagorapay_boletos pb ON pb.carne_id = l.id AND pb.status NOT IN ('cancelado','erro')
        WHERE l.codigo_carne = '$codigo_carne'
        ORDER BY l.datavenc ASC";

$res = $LOADMYSQL->query($sql);
if (!$res || $res->num_rows === 0) die('Nenhuma parcela encontrada.');

$parcelas = [];
while ($r = $res->fetch_assoc()) $parcelas[] = $r;

function fmt_linha($raw) {
    $d = preg_replace('/\D/','',$raw);
    if (strlen($d)===47)
        return substr($d,0,5).'.'.substr($d,5,5).' '.substr($d,10,5).'.'.substr($d,15,6).' '.substr($d,21,5).'.'.substr($d,26,6).' '.substr($d,32,1).' '.substr($d,33,14);
    return $raw;
}

// Busca HTML nativo
$cookies = [];
foreach ($_COOKIE as $k=>$v) $cookies[] = urlencode($k).'='.urlencode($v);
$ctx = stream_context_create(['http'=>['timeout'=>15,'follow_location'=>true,'header'=>'Cookie: '.implode('; ',$cookies)."\r\n"]]);
$html = @file_get_contents('http://127.0.0.1/boleto/carne.hhvm?tipo=3folhas&carne='.urlencode($codigo_carne).'&capa=sim&pp_bypass=1', false, $ctx);
if (!$html) die('<p style="padding:40px;color:red;">Erro ao carregar carnê.</p>');

// Corrige caminhos relativos
$base = 'http://' . $_SERVER['HTTP_HOST'];
$html = preg_replace('/\bsrc="(?!http|data)([^"]+)"/i', 'src="'.$base.'/boleto/$1"', $html);
$html = str_replace('http://127.0.0.1/', $base.'/', $html);

// Substitui linhas digitáveis
foreach ($parcelas as $p) {
    if (!empty($p['linha_mk']) && !empty($p['pp_linha'])) {
        $fmt = fmt_linha($p['pp_linha']);
        $html = str_replace(htmlspecialchars($p['linha_mk']), htmlspecialchars($fmt), $html);
        $html = str_replace($p['linha_mk'], $fmt, $html);
    }
}

// Remove background-image do CSS bollogo_XXX (evita "BOLETO PRÓPRIO" aparecer)
$html = preg_replace('/\.bollogo_XXX\s*\{[^}]*\}/s', '.bollogo_XXX { height: 40px; }', $html);

// Logo — injeta <img> apenas na 2ª bollogo_XXX de cada boleto (header ao lado do 999-7)
$logo_path = __DIR__.'/logo_boleto.png';
if (file_exists($logo_path)) {
    $logo_b64 = base64_encode(file_get_contents($logo_path));
    $logo_img = '<img src="data:image/png;base64,'.$logo_b64.'" style="height:38px;max-width:140px;object-fit:contain;print-color-adjust:exact;-webkit-print-color-adjust:exact;" alt="PagoraPay">';
    $count_logo = 0;
    $html = preg_replace_callback(
        '/<div class="bollogo_XXX"><\/div>/',
        function($m) use ($logo_img, &$count_logo) {
            $count_logo++;
            if ($count_logo % 2 === 1) {
                return '<div class="bollogo_XXX">'.$logo_img.'</div>';
            }
            return $m[0];
        },
        $html
    );
}

// Substitui a imagem placeholder (100x100) pelo QR PIX de cada parcela
// Filtra apenas parcelas com QR ativo
$parcelas_com_qr = array_values(array_filter($parcelas, function($p){ return !empty($p['pix_qrcode']); }));
$placeholder_pattern = '/<img src="data:image\/jpeg;base64,[^"]{100,}" width="100"[^>]*>/';
$pix_idx = 0;
$html = preg_replace_callback(
    $placeholder_pattern,
    function($m) use ($parcelas_com_qr, &$pix_idx) {
        $p = $parcelas_com_qr[$pix_idx] ?? null;
        $pix_idx++;
        if ($p && !empty($p['pix_qrcode'])) {
            return '<img src="data:image/png;base64,'.htmlspecialchars($p['pix_qrcode']).'" width="100" height="100" style="display:block;" alt="QR PIX">';
        }
        return $m[0];
    },
    $html
);

// Barra + CSS impressão
$barra = '<style>
  @media print { .pp-noprint{display:none!important;} img{print-color-adjust:exact;-webkit-print-color-adjust:exact;} }
</style>
<div class="pp-noprint" style="background:#1a56db;color:#fff;padding:10px;text-align:center;position:sticky;top:0;z-index:9999;">
  <button onclick="window.print()" style="background:#fff;color:#1a56db;border:none;padding:8px 20px;border-radius:4px;font-size:13px;font-weight:bold;cursor:pointer;margin:0 5px;">🖨️ Imprimir Carnê</button>
  <button onclick="try{window.parent.ppFechar();}catch(e){}window.close();" style="background:#e53e3e;color:#fff;border:none;padding:8px 20px;border-radius:4px;font-size:13px;font-weight:bold;cursor:pointer;margin:0 5px;">✕ Fechar</button>
</div>';

$html = preg_replace('/<body([^>]*)>/i', '<body$1>'.$barra, $html, 1);
echo $html;
