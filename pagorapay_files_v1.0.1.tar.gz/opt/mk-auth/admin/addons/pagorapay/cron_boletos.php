<?php
/**
 * cron_boletos.php — Cron PagoraPay MKAuth
 * Executa via crontab, ex: * * * * * php /opt/mk-auth/admin/addons/pagorapay/cron_boletos.php
 *
 * Seções:
 *   1. Cancela cobranças de títulos deletados no MKAuth
 *   2. Cancela cobranças de títulos pagos manualmente por outra forma
 *   3. Gera cobranças para títulos ainda sem boleto PagoraPay
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/boleto_api.php';

$log = __DIR__ . '/cron_log.txt';
function clog($m) { global $log; file_put_contents($log, '[' . date('Y-m-d H:i:s') . '] ' . $m . "\n", FILE_APPEND | LOCK_EX); }

// ── LOCKFILE — impede execução simultânea ────────────────────────────────────
$lockfile = sys_get_temp_dir() . '/pagorapay_cron.lock';
$lock = fopen($lockfile, 'c');
if (!$lock || !flock($lock, LOCK_EX | LOCK_NB)) {
    // Outro processo já está rodando — sai silenciosamente
    exit;
}
register_shutdown_function(function() use ($lock, $lockfile) {
    flock($lock, LOCK_UN);
    fclose($lock);
});

$numconta = intval($PAGORAPAY['numconta'] ?? 0);
if (!$numconta) { clog("numconta não configurado — verifique as configurações do addon."); exit; }

// ── 1. CANCELAMENTOS: títulos deletados no MKAuth com boleto ativo ───────────
$sql_cancel = "SELECT pb.id, pb.id_externo, pb.carne_id
               FROM pagorapay_boletos pb
               JOIN sis_lanc l ON l.id = pb.carne_id
               WHERE pb.status = 'pendente'
               AND l.numconta = $numconta
               AND l.deltitulo = 1";

$res_cancel = $LOADMYSQL->query($sql_cancel);
if ($res_cancel && $res_cancel->num_rows > 0) {
    clog("Seção 1: {$res_cancel->num_rows} boleto(s) para cancelar por deleção no MKAuth");
    while ($row = $res_cancel->fetch_assoc()) {
        $resultado = pagorapay_cancelar_boleto($row['id_externo'], (int)$row['id']);
        clog("  Cancelamento título #{$row['carne_id']}: " . $resultado['msg']);
        usleep(200000);
    }
}


// ── 1.5. VALOR ALTERADO: cancela boleto se valor do título mudou ────────────
$sql_valor = "SELECT pb.id, pb.id_externo, pb.carne_id, pb.valor AS valor_boleto, l.valor AS valor_titulo,
                     pb.vencimento AS venc_boleto, l.datavenc AS venc_titulo
              FROM pagorapay_boletos pb
              JOIN sis_lanc l ON l.id = pb.carne_id
              WHERE pb.status = 'pendente'
              AND l.numconta = $numconta
              AND l.deltitulo = 0
              AND (
                ABS(CAST(pb.valor AS DECIMAL(10,2)) - CAST(l.valor AS DECIMAL(10,2))) > 0.01
                OR DATE(pb.vencimento) != DATE(l.datavenc)
              )";

$res_valor = $LOADMYSQL->query($sql_valor);
if ($res_valor && $res_valor->num_rows > 0) {
    clog("Seção 1.5: {$res_valor->num_rows} boleto(s) com valor alterado — cancelando para reemitir");
    while ($row = $res_valor->fetch_assoc()) {
        clog("  Título #{$row['carne_id']}: R$ {$row['valor_boleto']}→{$row['valor_titulo']} | venc {$row['venc_boleto']}→" . substr($row['venc_titulo'],0,10));
        $resultado = pagorapay_cancelar_boleto($row['id_externo'], (int)$row['id']);
        clog("  Cancelamento: " . $resultado['msg']);
        usleep(200000);
    }
}

// ── 2. PAGAMENTOS MANUAIS: quitados por outra forma → cancela na PagoraPay ───
$sql_pago = "SELECT pb.id, pb.id_externo, pb.carne_id, l.formapag
             FROM pagorapay_boletos pb
             JOIN sis_lanc l ON l.id = pb.carne_id
             WHERE pb.status = 'pendente'
             AND l.numconta = $numconta
             AND l.status = 'pago'
             AND (l.formapag IS NULL OR l.formapag NOT LIKE '%PagoraPay%')";

$res_pago = $LOADMYSQL->query($sql_pago);
if ($res_pago && $res_pago->num_rows > 0) {
    clog("Seção 2: {$res_pago->num_rows} boleto(s) para cancelar por pagamento manual");
    while ($row = $res_pago->fetch_assoc()) {
        $resultado = pagorapay_cancelar_boleto($row['id_externo'], (int)$row['id']);
        clog("  Cancelamento por pagto manual título #{$row['carne_id']} (forma: {$row['formapag']}): " . $resultado['msg']);
        usleep(200000);
    }
}

// ── 3. GERAÇÃO: títulos em aberto sem boleto PagoraPay ───────────────────────
$sql = "SELECT l.id, l.login, l.valor, l.datavenc, l.obs, l.referencia
        FROM sis_lanc l
        LEFT JOIN pagorapay_boletos pb ON pb.carne_id = l.id AND pb.status NOT IN ('cancelado','erro')
        WHERE l.numconta = $numconta
        AND l.status = 'aberto'
        AND l.deltitulo = 0
        AND pb.id IS NULL
        AND l.datavenc >= CURDATE()
        ORDER BY l.datavenc ASC
        LIMIT 100";

$res = $LOADMYSQL->query($sql);
if (!$res) { clog("Erro query geração: " . $LOADMYSQL->error); exit; }

$total = $res->num_rows;
if ($total === 0) {
    clog("Seção 3: nenhum título pendente de boleto.");
    exit;
}

clog("Seção 3: $total título(s) sem boleto PagoraPay — gerando...");

while ($lanc = $res->fetch_assoc()) {
    $login_safe = $LOADMYSQL->real_escape_string($lanc['login']);
    $res_c = $LOADMYSQL->query("SELECT id, nome, cpf_cnpj FROM sis_cliente WHERE login='$login_safe' LIMIT 1");
    if (!$res_c || $res_c->num_rows === 0) { clog("  Cliente não encontrado: {$lanc['login']}"); continue; }
    $cli = $res_c->fetch_assoc();

    if (empty(preg_replace('/\D/', '', $cli['cpf_cnpj'] ?? ''))) { clog("  Sem CPF/CNPJ: {$lanc['login']}"); continue; }

    $vencimento = substr($lanc['datavenc'], 0, 10);
    $valor      = floatval($lanc['valor']);
    if ($valor < 5.00) { clog("  Valor abaixo do mínimo (R$ $valor): título #{$lanc['id']}"); continue; }

    $resultado = pagorapay_emitir_boleto([
        'cliente_id' => $cli['id'],
        'valor'      => $valor,
        'vencimento' => $vencimento,
        'titulo_id'  => $lanc['id'],
        'descricao'  => $lanc['obs'] ?? 'Mensalidade',
        'referencia' => $lanc['referencia'] ?? '',
    ]);

    clog("  #{$lanc['id']} {$cli['nome']}: " . $resultado['msg']);
    usleep(200000);
}

clog("Cron finalizado.");
