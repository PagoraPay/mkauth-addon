<?php
/**
 * check_boleto.php — Verifica se existe boleto PagoraPay ativo
 * para um título ou carnê. Usado pelo addon.js para decidir se
 * intercepta o clique ou deixa o MKAuth abrir o boleto nativo.
 */
require_once __DIR__ . '/config.php';

header('Content-Type: application/json');

// ── Por titulo_id ─────────────────────────────────────────────────────────────
if (!empty($_GET['titulo_id'])) {
    $tid = intval($_GET['titulo_id']);
    $res = $LOADMYSQL->query("SELECT id, boleto_url, link_pagamento
                               FROM pagorapay_boletos
                               WHERE carne_id='$tid'
                               AND status NOT IN ('cancelado','erro')
                               ORDER BY id DESC LIMIT 1");
    if ($res && $row = $res->fetch_assoc()) {
        echo json_encode([
            'existe' => true,
            'id'     => $row['id'],
            'url'    => $row['boleto_url'] ?: $row['link_pagamento'],
        ]);
    } else {
        echo json_encode(['existe' => false, 'url' => '']);
    }
    exit;
}

// ── Por codigo_carne ──────────────────────────────────────────────────────────
if (!empty($_GET['codigo_carne'])) {
    $cc  = $LOADMYSQL->real_escape_string($_GET['codigo_carne']);
    $res = $LOADMYSQL->query("SELECT COUNT(*) AS total
                               FROM pagorapay_boletos pb
                               JOIN sis_lanc l ON l.id = pb.carne_id
                               WHERE l.codigo_carne='$cc'
                               AND pb.status NOT IN ('cancelado','erro')");
    $row = $res ? $res->fetch_assoc() : null;
    echo json_encode(['existe' => ($row['total'] ?? 0) > 0]);
    exit;
}

echo json_encode(['existe' => false, 'url' => '']);
