<?php
/**
 * boleto.php — Página local de cobrança PagoraPay
 * Layout profissional com PIX + Boleto
 */
error_reporting(0);
ini_set('display_errors', 0);

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/boleto_api.php';

$titulo_id  = intval($_GET['titulo_id'] ?? 0);
$cliente_id = $_GET['cliente_id'] ?? '';
$forcar_novo = isset($_GET['novo']);

if (!$titulo_id && !$cliente_id) {
    die('Parâmetros inválidos.');
}

// Busca dados do título no MKAuth
$titulo = null;
if ($titulo_id) {
    $res = $LOADMYSQL->query("SELECT id, obs as descricao, valor, datavenc as vencimento, login, referencia
                               FROM sis_lanc WHERE id='$titulo_id' LIMIT 1");
    if ($res && $res->num_rows > 0) {
        $titulo = $res->fetch_assoc();
    } else {
        $res2 = $LOADMYSQL->query("SELECT id, descricao, valor, vencimento, login, referencia
                                    FROM vtab_titulos WHERE id='$titulo_id' LIMIT 1");
        if ($res2) $titulo = $res2->fetch_assoc();
    }
}

if (!$titulo) {
    die('<div style="font-family:sans-serif;padding:40px;text-align:center;color:#e53e3e;">⚠️ Título #'.$titulo_id.' não encontrado.</div>');
}

// Busca cliente
if (!$cliente_id) {
    $login_safe = $LOADMYSQL->real_escape_string($titulo['login']);
    $res_c = $LOADMYSQL->query("SELECT id, nome, cpf_cnpj, email, celular FROM sis_cliente WHERE login='$login_safe' LIMIT 1");
    if ($res_c && $res_c->num_rows > 0) {
        $c = $res_c->fetch_assoc();
        $cliente_id = $c['id'];
    }
} else {
    $cid_safe = $LOADMYSQL->real_escape_string($cliente_id);
    $res_c = $LOADMYSQL->query("SELECT id, nome, cpf_cnpj, email, celular FROM sis_cliente WHERE id='$cid_safe' LIMIT 1");
    if ($res_c) $c = $res_c->fetch_assoc();
}

if (empty($c)) die('<div style="font-family:sans-serif;padding:40px;color:#e53e3e;">Cliente não encontrado.</div>');

// Formata vencimento
$vencimento_raw = $titulo['vencimento'] ?? '';
$vencimento_fmt = substr($vencimento_raw, 0, 10);
if (empty($vencimento_fmt) || $vencimento_fmt === '0000-00-00') {
    $vencimento_fmt = date('Y-m-d', strtotime('+3 days'));
}
$vencimento_br = date('d/m/Y', strtotime($vencimento_fmt));

// Formata valor
$valor_raw = $titulo['valor'] ?? '0';
$valor_float = floatval(str_replace(',', '.', preg_replace('/\.(?=.*\.)/', '', $valor_raw)));
$valor_fmt = 'R$ ' . number_format($valor_float, 2, ',', '.');

// Verifica/gera cobrança
$boleto = null;
if (!$forcar_novo) {
    $tid_safe = $LOADMYSQL->real_escape_string((string)$titulo_id);
    $res_b = $LOADMYSQL->query("SELECT * FROM pagorapay_boletos WHERE carne_id='$tid_safe' AND status!='cancelado' ORDER BY id DESC LIMIT 1");
    if ($res_b && $res_b->num_rows > 0) {
        $boleto = $res_b->fetch_assoc();
    }
}

$erro = '';
if (!$boleto) {
    $resultado = pagorapay_emitir_boleto([
        'cliente_id' => $c['id'],
        'valor'      => $valor_float,
        'vencimento' => $vencimento_fmt,
        'titulo_id'  => $titulo_id,
        'descricao'  => ($titulo['descricao'] ?? 'Mensalidade'),
        'referencia' => ($titulo['referencia'] ?? ''),
    ]);
    if ($resultado['success']) {
        $tid_safe = $LOADMYSQL->real_escape_string((string)$titulo_id);
        $res_b = $LOADMYSQL->query("SELECT * FROM pagorapay_boletos WHERE carne_id='$tid_safe' AND status!='cancelado' ORDER BY id DESC LIMIT 1");
        if ($res_b && $res_b->num_rows > 0) {
            $boleto = $res_b->fetch_assoc();
        }
    } else {
        $erro = $resultado['msg'];
    }
}

// Dados do provedor
$res_prov = $LOADMYSQL->query("SELECT nome, razao as razao_social, cnpj FROM sis_provedor LIMIT 1");
$prov = $res_prov ? $res_prov->fetch_assoc() : [];
$nome_prov = $prov['nome'] ?? 'Provedor Internet';
$cnpj_prov = $prov['cnpj'] ?? '';

$pix_copia_cola = $boleto['pix_copia_cola'] ?? '';
$pix_qrcode     = $boleto['pix_qrcode'] ?? '';
$boleto_url     = $boleto['boleto_url'] ?? '';
$link_pagamento = $boleto['link_pagamento'] ?? '';
$status         = $boleto['status'] ?? 'pendente';
$gerado_em      = $boleto ? date('d/m/Y H:i', strtotime($boleto['created_at'])) : '';
$referencia     = $titulo['referencia'] ?? '';

$cpf_fmt = $c['cpf_cnpj'] ?? '';
if (strlen(preg_replace('/\D/','',$cpf_fmt)) === 11) {
    $n = preg_replace('/\D/','',$cpf_fmt);
    $cpf_fmt = substr($n,0,3).'.'.substr($n,3,3).'.'.substr($n,6,3).'-'.substr($n,9,2);
} elseif (strlen(preg_replace('/\D/','',$cpf_fmt)) === 14) {
    $n = preg_replace('/\D/','',$cpf_fmt);
    $cpf_fmt = substr($n,0,2).'.'.substr($n,2,3).'.'.substr($n,5,3).'/'.substr($n,8,4).'-'.substr($n,12,2);
}

$status_label = match($status) {
    'pago'      => ['✅ PAGO', '#22543d', '#c6f6d5'],
    'cancelado' => ['❌ CANCELADO', '#742a2a', '#fed7d7'],
    default     => ['⏳ AGUARDANDO', '#744210', '#fefcbf'],
};
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Cobrança — <?= htmlspecialchars($nome_prov) ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet">
<style>
  :root {
    --bg: #f0f4f8;
    --card: #ffffff;
    --border: #e2e8f0;
    --text: #1a202c;
    --text-muted: #718096;
    --accent: #2b6cb0;
    --accent-light: #ebf8ff;
    --accent-dark: #1a4a7a;
    --pix: #32d583;
    --pix-dark: #05603a;
    --pix-bg: #f0fdf4;
    --radius: 12px;
    --shadow: 0 1px 3px rgba(0,0,0,.08), 0 4px 16px rgba(0,0,0,.06);
  }
  * { box-sizing:border-box; margin:0; padding:0; }
  body {
    font-family:'DM Sans', sans-serif;
    background: var(--bg);
    min-height:100vh;
    padding: 20px 16px 40px;
    color: var(--text);
  }
  .page { max-width: 520px; margin: 0 auto; }

  /* HEADER */
  .header {
    background: var(--accent);
    border-radius: var(--radius) var(--radius) 0 0;
    padding: 20px 24px;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
  }
  .header-logo {
    width: 40px; height: 40px;
    background: rgba(255,255,255,.15);
    border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.3rem; flex-shrink: 0;
  }
  .header-info { flex: 1; }
  .header-info h1 { font-size: 1rem; font-weight: 700; letter-spacing: -.01em; }
  .header-info p  { font-size: .78rem; opacity: .75; margin-top: 1px; }
  .status-pill {
    display: inline-flex; align-items: center;
    padding: 4px 12px; border-radius: 20px;
    font-size: .73rem; font-weight: 700; letter-spacing: .03em;
    background: rgba(255,255,255,.2); color: #fff;
    flex-shrink: 0;
  }

  /* CARD BASE */
  .card {
    background: var(--card);
    border: 1px solid var(--border);
    border-top: none;
    padding: 20px 24px;
  }
  .card:last-child { border-radius: 0 0 var(--radius) var(--radius); }
  .card + .card { border-top: 1px solid var(--border); }
  .card-title {
    font-size: .7rem; font-weight: 700; letter-spacing: .08em;
    text-transform: uppercase; color: var(--text-muted);
    margin-bottom: 14px; display: flex; align-items: center; gap: 6px;
  }

  /* DADOS GRID */
  .dados-grid {
    display: grid; grid-template-columns: 1fr 1fr;
    gap: 14px;
  }
  .dado { }
  .dado label { font-size: .7rem; font-weight: 600; color: var(--text-muted); text-transform: uppercase; letter-spacing: .05em; display: block; margin-bottom: 2px; }
  .dado span  { font-size: .92rem; font-weight: 600; color: var(--text); }
  .dado.full  { grid-column: 1 / -1; }
  .valor-destaque { font-size: 1.6rem !important; font-weight: 700 !important; color: var(--accent) !important; }

  /* SEPARADOR */
  .sep {
    border: none;
    border-top: 1px dashed var(--border);
    margin: 16px 0;
  }

  /* PIX */
  .pix-box {
    background: var(--pix-bg);
    border: 1.5px solid #86efac;
    border-radius: 10px;
    padding: 18px;
  }
  .pix-header {
    display: flex; align-items: center; gap: 10px; margin-bottom: 14px;
  }
  .pix-icon {
    width: 36px; height: 36px; background: var(--pix); border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.1rem; flex-shrink: 0;
  }
  .pix-title { font-weight: 700; font-size: .95rem; color: var(--pix-dark); }
  .pix-sub   { font-size: .75rem; color: #276749; margin-top: 1px; }
  .pix-inner {
    display: flex; gap: 14px; align-items: flex-start;
  }
  .pix-qr {
    width: 110px; height: 110px; flex-shrink: 0;
    border-radius: 8px; border: 2px solid #86efac;
    background: #fff; display: flex; align-items: center; justify-content: center;
    overflow: hidden;
  }
  .pix-qr img { width: 100%; height: 100%; }
  .pix-right { flex: 1; min-width: 0; }
  .pix-label { font-size: .7rem; font-weight: 600; color: #276749; margin-bottom: 5px; }
  .pix-code {
    font-family: 'DM Mono', monospace;
    font-size: .7rem;
    background: #fff;
    border: 1px solid #86efac;
    border-radius: 6px;
    padding: 8px 10px;
    word-break: break-all;
    color: #1a202c;
    line-height: 1.5;
    max-height: 72px;
    overflow: hidden;
    margin-bottom: 8px;
    cursor: pointer;
    transition: background .15s;
  }
  .pix-code:hover { background: #f0fdf4; }
  .btn-copy {
    width: 100%;
    background: var(--pix);
    color: #fff;
    border: none;
    border-radius: 7px;
    padding: 9px;
    font-family: 'DM Sans', sans-serif;
    font-size: .83rem;
    font-weight: 700;
    cursor: pointer;
    transition: background .15s, transform .1s;
    display: flex; align-items: center; justify-content: center; gap: 6px;
  }
  .btn-copy:hover  { background: #15803d; }
  .btn-copy:active { transform: scale(.97); }
  .copied-msg {
    display: none;
    text-align: center; font-size: .75rem; color: var(--pix-dark);
    font-weight: 600; margin-top: 5px;
  }

  /* BOLETO */
  .boleto-box {
    background: var(--accent-light);
    border: 1.5px solid #bee3f8;
    border-radius: 10px;
    padding: 16px;
    margin-top: 14px;
  }
  .boleto-header {
    display: flex; align-items: center; gap: 10px; margin-bottom: 12px;
  }
  .boleto-icon {
    width: 36px; height: 36px; background: var(--accent); border-radius: 8px;
    display: flex; align-items: center; justify-content: center;
    font-size: 1.1rem; flex-shrink: 0;
  }
  .boleto-title { font-weight: 700; font-size: .95rem; color: var(--accent-dark); }
  .boleto-sub   { font-size: .75rem; color: #2c5282; margin-top: 1px; }
  .btn-boleto {
    display: flex; align-items: center; justify-content: center; gap: 8px;
    width: 100%;
    background: var(--accent);
    color: #fff;
    text-decoration: none;
    border-radius: 7px;
    padding: 10px;
    font-size: .88rem;
    font-weight: 700;
    transition: background .15s, transform .1s;
  }
  .btn-boleto:hover  { background: var(--accent-dark); }
  .btn-boleto:active { transform: scale(.97); }
  .boleto-venc { text-align: center; font-size: .73rem; color: #2c5282; margin-top: 6px; }

  /* RODAPÉ */
  .footer-card {
    background: var(--card);
    border: 1px solid var(--border);
    border-top: none;
    border-radius: 0 0 var(--radius) var(--radius);
    padding: 14px 24px;
    display: flex; align-items: center; justify-content: space-between;
    flex-wrap: wrap; gap: 8px;
  }
  .footer-brand { font-size: .73rem; color: var(--text-muted); }
  .footer-brand strong { color: var(--text); }
  .btn-print {
    background: none; border: 1px solid var(--border);
    border-radius: 6px; padding: 5px 12px;
    font-family: 'DM Sans', sans-serif;
    font-size: .78rem; cursor: pointer; color: var(--text-muted);
    transition: all .15s;
    display: flex; align-items: center; gap: 5px;
  }
  .btn-print:hover { border-color: var(--accent); color: var(--accent); }

  /* ERRO */
  .erro-card {
    background: #fff5f5; border: 1px solid #feb2b2;
    border-radius: var(--radius); padding: 24px;
    text-align: center; color: #c53030;
  }
  .erro-card h3 { margin-bottom: 8px; }

  /* NOVO */
  .btn-novo {
    display: block; text-align: center;
    background: none; border: 1px dashed var(--border);
    color: var(--text-muted); font-size: .78rem;
    border-radius: 7px; padding: 8px;
    cursor: pointer; margin-top: 8px; width: 100%;
    font-family: 'DM Sans', sans-serif;
    transition: all .15s;
  }
  .btn-novo:hover { border-color: #e53e3e; color: #e53e3e; }

  .pago-overlay {
    background: #c6f6d5; border: 1.5px solid #68d391;
    border-radius: 10px; padding: 20px;
    text-align: center;
  }
  .pago-overlay h2 { color: #22543d; font-size: 1.2rem; margin-bottom: 4px; }
  .pago-overlay p  { color: #276749; font-size: .85rem; }

  @media print {
    body { background: #fff; padding: 0; }
    .btn-print, .btn-novo, .footer-card { display: none !important; }
    .page { max-width: 100%; }
    .header { border-radius: 0; }
  }
  @media (max-width: 420px) {
    .pix-inner { flex-direction: column; align-items: center; }
    .pix-qr { width: 140px; height: 140px; }
    .pix-right { width: 100%; }
    .dados-grid { grid-template-columns: 1fr; }
  }
</style>
</head>
<body>
<div class="page">

  <?php if ($erro): ?>
    <div class="erro-card">
      <h3>Erro ao gerar cobrança</h3>
      <p><?= htmlspecialchars($erro) ?></p>
    </div>
  <?php else: ?>

  <!-- HEADER -->
  <div class="header">
    <div class="header-logo">💳</div>
    <div class="header-info">
      <h1><?= htmlspecialchars($nome_prov) ?></h1>
      <p>Cobrança <?= htmlspecialchars($referencia) ?></p>
    </div>
    <div class="status-pill"><?= $status_label[0] ?></div>
  </div>

  <!-- DADOS DO CLIENTE -->
  <div class="card">
    <div class="card-title">👤 Dados do pagador</div>
    <div class="dados-grid">
      <div class="dado full">
        <label>Cliente</label>
        <span><?= htmlspecialchars($c['nome']) ?></span>
      </div>
      <div class="dado">
        <label>CPF / CNPJ</label>
        <span><?= htmlspecialchars($cpf_fmt) ?></span>
      </div>
      <div class="dado">
        <label>Referência</label>
        <span><?= htmlspecialchars($referencia ?: '—') ?></span>
      </div>
    </div>
  </div>

  <!-- VALOR E VENCIMENTO -->
  <div class="card">
    <div class="dados-grid">
      <div class="dado">
        <label>Valor</label>
        <span class="valor-destaque"><?= $valor_fmt ?></span>
      </div>
      <div class="dado">
        <label>Vencimento</label>
        <span><?= $vencimento_br ?></span>
      </div>
      <?php if ($gerado_em): ?>
      <div class="dado">
        <label>Gerado em</label>
        <span><?= $gerado_em ?></span>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <!-- FORMAS DE PAGAMENTO -->
  <div class="card">
    <div class="card-title">💰 Formas de pagamento</div>

    <?php if ($status === 'pago'): ?>
      <div class="pago-overlay">
        <h2>✅ Pagamento confirmado!</h2>
        <p>Esta cobrança já foi paga. Obrigado!</p>
      </div>

    <?php else: ?>

      <?php if ($pix_copia_cola): ?>
      <!-- PIX -->
      <div class="pix-box">
        <div class="pix-header">
          <div class="pix-icon">⚡</div>
          <div>
            <div class="pix-title">Pagar com PIX</div>
            <div class="pix-sub">Instantâneo, 24h por dia, 7 dias por semana</div>
          </div>
        </div>
        <div class="pix-inner">
          <?php if ($pix_qrcode): ?>
          <div class="pix-qr">
            <img src="data:image/png;base64,<?= htmlspecialchars($pix_qrcode) ?>" alt="QR Code PIX">
          </div>
          <?php endif; ?>
          <div class="pix-right">
            <div class="pix-label">Código PIX Copia e Cola</div>
            <div class="pix-code" id="pixCode" onclick="copiarPix()"><?= htmlspecialchars($pix_copia_cola) ?></div>
            <button class="btn-copy" onclick="copiarPix()" id="btnCopy">
              <span>📋</span> Copiar código PIX
            </button>
            <div class="copied-msg" id="copiedMsg">✅ Código copiado!</div>
          </div>
        </div>
      </div>
      <?php endif; ?>

      <?php if ($boleto_url || $link_pagamento): ?>
      <!-- BOLETO -->
      <div class="boleto-box">
        <div class="boleto-header">
          <div class="boleto-icon">🏦</div>
          <div>
            <div class="boleto-title">Pagar com Boleto Bancário</div>
            <div class="boleto-sub">Pague em qualquer banco, lotérica ou app</div>
          </div>
        </div>
        <a href="<?= htmlspecialchars($boleto_url ?: $link_pagamento) ?>" target="_blank" class="btn-boleto">
          📄 Abrir / Imprimir Boleto
        </a>
        <div class="boleto-venc">Vencimento: <?= $vencimento_br ?> · Pague em qualquer banco ou lotérica</div>
      </div>
      <?php endif; ?>

      <?php if ($link_pagamento && $link_pagamento !== $boleto_url): ?>
      <div style="margin-top:10px;text-align:center;">
        <a href="<?= htmlspecialchars($link_pagamento) ?>" target="_blank"
           style="color:var(--accent);font-size:.78rem;text-decoration:none;">
          🔗 Ver página de pagamento PagoraPay
        </a>
      </div>
      <?php endif; ?>

    <?php endif; ?>

    <?php if ($status !== 'pago'): ?>
    <form method="GET" style="margin-top:4px;">
      <input type="hidden" name="titulo_id" value="<?= $titulo_id ?>">
      <input type="hidden" name="cliente_id" value="<?= htmlspecialchars($cliente_id) ?>">
      <input type="hidden" name="novo" value="1">
      <button type="submit" class="btn-novo" onclick="return confirm('Gerar uma nova cobrança? A atual permanecerá ativa na PagoraPay.')">
        🔄 Gerar nova cobrança
      </button>
    </form>
    <?php endif; ?>
  </div>

  <!-- RODAPÉ -->
  <div class="footer-card">
    <div class="footer-brand">
      <strong>PagoraPay</strong> · Addon MKAuth
    </div>
    <button class="btn-print" onclick="window.print()">🖨️ Imprimir</button>
  </div>

  <?php endif; ?>
</div>

<script>
function copiarPix() {
  const code = document.getElementById('pixCode')?.textContent?.trim();
  if (!code) return;
  navigator.clipboard?.writeText(code).then(() => {
    const btn = document.getElementById('btnCopy');
    const msg = document.getElementById('copiedMsg');
    if (btn) { btn.innerHTML = '<span>✅</span> Copiado!'; btn.style.background = '#15803d'; }
    if (msg) msg.style.display = 'block';
    setTimeout(() => {
      if (btn) { btn.innerHTML = '<span>📋</span> Copiar código PIX'; btn.style.background = ''; }
      if (msg) msg.style.display = 'none';
    }, 3000);
  }).catch(() => {
    // fallback
    const ta = document.createElement('textarea');
    ta.value = code;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    const btn = document.getElementById('btnCopy');
    if (btn) { btn.innerHTML = '<span>✅</span> Copiado!'; }
    setTimeout(() => { if (btn) btn.innerHTML = '<span>📋</span> Copiar código PIX'; }, 3000);
  });
}
</script>
</body>
</html>
