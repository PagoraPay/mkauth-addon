<?php
require_once __DIR__ . '/config.php';

$layout_url = $_GET['url'] ?? '';
$titulo_ids = array_map('intval', (array)($_GET['titulo'] ?? []));
if (!$layout_url || empty($titulo_ids)) die('Parâmetros inválidos.');

// Busca dados PagoraPay
$ids_str = implode(',', $titulo_ids);
$sql = "SELECT l.id, l.nossonum, l.linhadig as linha_mk,
               pb.linha_digitavel as pp_linha, pb.pix_qrcode
        FROM sis_lanc l
        LEFT JOIN pagorapay_boletos pb ON pb.titulo_id = l.id AND pb.status NOT IN ('cancelado','erro')
        WHERE l.id IN ($ids_str)
        ORDER BY l.datavenc ASC";
$res = $LOADMYSQL->query($sql);
$titulos = [];
while ($r = $res->fetch_assoc()) $titulos[] = $r;

function fmt_linha($raw) {
    $d = preg_replace('/\D/', '', $raw);
    if (strlen($d) === 47)
        return substr($d,0,5).'.'.substr($d,5,5).' '.substr($d,10,5).'.'.substr($d,15,6).' '.
               substr($d,21,5).'.'.substr($d,26,6).' '.substr($d,32,1).' '.substr($d,33,14);
    return $raw;
}

// Prepara dados para o JS
$js_data = [];
foreach ($titulos as $t) {
    $js_data[] = [
        'linha_mk'  => $t['linha_mk'] ?? '',
        'pp_linha'  => $t['pp_linha'] ? fmt_linha($t['pp_linha']) : '',
        'pix_qrcode'=> $t['pix_qrcode'] ?? '',
    ];
}

$logo_path = __DIR__.'/logo_boleto.png';
$logo_b64 = file_exists($logo_path) ? base64_encode(file_get_contents($logo_path)) : '';

// Garante URL interna correta
if (!str_starts_with($layout_url, '/')) $layout_url = '/admin/' . $layout_url;

$js_data_json = json_encode($js_data);
$logo_json = json_encode($logo_b64);
$ids_json = json_encode($titulo_ids);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Boleto</title>
<style>
* { margin:0; padding:0; box-sizing:border-box; }
body { background:#fff; }
.pp-noprint { background:#1a56db; color:#fff; padding:10px; text-align:center; position:fixed; top:0; left:0; right:0; z-index:9999; }
.pp-noprint button { border:none; padding:8px 20px; border-radius:4px; font-size:13px; font-weight:bold; cursor:pointer; margin:0 5px; }
iframe { border:none; width:100%; height:calc(100vh - 48px); margin-top:48px; display:block; }
@media print { .pp-noprint{display:none!important;} iframe{margin-top:0;height:100vh;} }
</style>
</head>
<body>

<div class="pp-noprint" id="pp-bar">
  <button onclick="printFrame()" style="background:#fff;color:#1a56db;">🖨️ Imprimir</button>
  <button onclick="window.close();" style="background:#e53e3e;color:#fff;">✕ Fechar</button>
  <span id="pp-status" style="font-size:12px;margin-left:10px;opacity:.8;"></span>
</div>

<!-- Form POST que carrega o layout MKAuth no iframe (usa sessão do browser) -->
<form id="mk-form" method="POST" action="<?= htmlspecialchars($layout_url) ?>" target="mk-frame" style="display:none">
<?php foreach ($titulo_ids as $id): ?>
  <input type="hidden" name="titulo[]" value="<?= $id ?>">
<?php endforeach; ?>
</form>
<iframe name="mk-frame" id="mk-frame"></iframe>

<script>
var PP_DATA = <?= $js_data_json ?>;
var PP_LOGO = <?= $logo_json ?>;

function printFrame() {
  var frame = document.getElementById('mk-frame');
  frame.contentWindow.focus();
  frame.contentWindow.print();
}

function injectPagoraPay(doc) {
  var status = document.getElementById('pp-status');

  // 1. Remove background-image "BOLETO PRÓPRIO" no CSS
  try {
    var styles = doc.querySelectorAll('style');
    styles.forEach(function(s) {
      s.textContent = s.textContent.replace(/\.bollogo_XXX\s*\{[^}]*\}/g, '.bollogo_XXX { height: 40px; }');
    });
  } catch(e) {}

  // 2. Substitui linhas digitáveis
  PP_DATA.forEach(function(t) {
    if (!t.linha_mk || !t.pp_linha) return;
    var walker = doc.createTreeWalker(doc.body, NodeFilter.SHOW_TEXT);
    var nodes = [];
    while(walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(function(node) {
      if (node.nodeValue && node.nodeValue.includes(t.linha_mk)) {
        node.nodeValue = node.nodeValue.split(t.linha_mk).join(t.pp_linha);
      }
    });
  });

  // 3. Logo PagoraPay na 1ª bollogo_XXX
  if (PP_LOGO) {
    var logos = doc.querySelectorAll('.bollogo_XXX');
    var count = 0;
    logos.forEach(function(el) {
      count++;
      if (count % 2 === 1) {
        el.innerHTML = '<img src="data:image/png;base64,' + PP_LOGO + '" style="height:38px;max-width:140px;object-fit:contain;" alt="PagoraPay">';
      }
    });
  }

  // 4. Substitui QR placeholders pelo QR PIX real
  var imgs = doc.querySelectorAll('img');
  var pix_idx = 0;
  imgs.forEach(function(img) {
    var src = img.getAttribute('src') || '';
    if (src.startsWith('data:image/jpeg;base64,') && src.length > 200) {
      var t = PP_DATA[pix_idx] || null;
      pix_idx++;
      if (t && t.pix_qrcode) {
        var wrapper = doc.createElement('div');
        wrapper.style.cssText = 'text-align:center;display:inline-block;';
        var newImg = doc.createElement('img');
        newImg.src = 'data:image/png;base64,' + t.pix_qrcode;
        newImg.width = 150; newImg.height = 150;
        newImg.style.display = 'block';
        var label = doc.createElement('span');
        label.style.cssText = 'display:block;font-size:11px;font-weight:bold;color:#32a852;margin-top:3px;font-family:Arial,sans-serif;';
        label.textContent = '⚡ Pague com PIX';
        wrapper.appendChild(newImg);
        wrapper.appendChild(label);
        img.parentNode.replaceChild(wrapper, img);
      }
    }
  });

  if (status) status.textContent = '✓ Dados PagoraPay injetados';
}

// Submete o form para carregar o iframe
document.addEventListener('DOMContentLoaded', function() {
  document.getElementById('mk-form').submit();

  var frame = document.getElementById('mk-frame');
  frame.addEventListener('load', function() {
    try {
      var doc = frame.contentDocument || frame.contentWindow.document;
      if (doc && doc.body) {
        injectPagoraPay(doc);
      }
    } catch(e) {
      console.warn('Inject error:', e);
    }
  });
});
</script>
</body>
</html>
