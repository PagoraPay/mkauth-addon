<?php
// Baseado no barcode.php do addon CodeLume/MKAuth
function fbarcode($valor) {
    $fino  = 1;
    $largo = 3;
    $altura = 52;

    $barcodes[0] = "00110";
    $barcodes[1] = "10001";
    $barcodes[2] = "01001";
    $barcodes[3] = "11000";
    $barcodes[4] = "00101";
    $barcodes[5] = "10100";
    $barcodes[6] = "01100";
    $barcodes[7] = "00011";
    $barcodes[8] = "10010";
    $barcodes[9] = "01010";

    for ($f1 = 9; $f1 >= 0; $f1--) {
        for ($f2 = 9; $f2 >= 0; $f2--) {
            $f = ($f1 * 10) + $f2;
            $texto = "";
            for ($i = 1; $i < 6; $i++) {
                $texto .= substr($barcodes[$f1], ($i-1), 1) . substr($barcodes[$f2], ($i-1), 1);
            }
            $barcodes[$f] = $texto;
        }
    }

    $b_img = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAABQAQMAAAAa6XZvAAAAA1BMVEX///+nxBvIAAAADElEQVR42mNgGFkAAADwAAE4aVpRAAAAAElFTkSuQmCC";
    $p_img = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAoAAABQAQMAAAAa6XZvAAAAA1BMVEUAAACnej3aAAAADElEQVR42mNgGFkAAADwAAE4aVpRAAAAAElFTkSuQmCC";

    ?><img src=<?php echo $p_img ?> width=<?php echo $fino ?> height=<?php echo $altura ?> border=0><img
    src=<?php echo $b_img ?> width=<?php echo $fino ?> height=<?php echo $altura ?> border=0><img
    src=<?php echo $p_img ?> width=<?php echo $fino ?> height=<?php echo $altura ?> border=0><img
    src=<?php echo $b_img ?> width=<?php echo $fino ?> height=<?php echo $altura ?> border=0><img
    <?php
    $texto = $valor;
    if ((strlen($texto) % 2) != 0) $texto = "0" . $texto;

    while (strlen($texto) > 0) {
        $i = round(substr($texto, 0, 2));
        $texto = substr($texto, 2);
        $f = $barcodes[$i];
        for ($i = 1; $i < 11; $i += 2) {
            $f1 = (substr($f, ($i-1), 1) == "0") ? $fino : $largo;
            ?>
    src=<?php echo $p_img ?> width=<?php echo $f1 ?> height=<?php echo $altura ?> border=0><img
    <?php
            $f2 = (substr($f, $i, 1) == "0") ? $fino : $largo;
            ?>
    src=<?php echo $b_img ?> width=<?php echo $f2 ?> height=<?php echo $altura ?> border=0><img
    <?php
        }
    }
    ?>
    src=<?php echo $p_img ?> width=<?php echo $largo ?> height=<?php echo $altura ?> border=0><img
    src=<?php echo $b_img ?> width=<?php echo $fino ?>  height=<?php echo $altura ?> border=0><img
    src=<?php echo $p_img ?> width=<?php echo 1 ?>      height=<?php echo $altura ?> border=0>
<?php
}
