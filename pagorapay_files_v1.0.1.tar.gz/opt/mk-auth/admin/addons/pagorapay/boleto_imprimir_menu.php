<?php
require_once __DIR__ . '/config.php';

$titulo_ids = array_map('intval', (array)($_GET['titulo'] ?? []));
if (empty($titulo_ids)) die('Nenhum título informado.');

$ids_str = implode(',', $titulo_ids);
$sql = "SELECT pb.titulo_id FROM pagorapay_boletos pb
        WHERE pb.titulo_id IN ($ids_str) AND pb.status NOT IN ('cancelado','erro')";
$res = $LOADMYSQL->query($sql);
$boletos_pp = [];
while ($r = $res->fetch_assoc()) $boletos_pp[] = intval($r['titulo_id']);

$tem_pp = count($boletos_pp) > 0;
$login = $_GET['login'] ?? '';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="utf-8">
<title>Imprimir Boletos</title>
<style>
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: Arial, sans-serif; background: #f5f5f5; }
.header { background: #1a56db; color: #fff; padding: 14px 20px; font-size: 15px; font-weight: bold; }
.container { padding: 12px; }
.card {
  background: #fff; border: 2px solid #ddd; border-radius: 8px;
  margin-bottom: 10px; padding: 16px; display: flex; align-items: center;
  gap: 16px; cursor: pointer; transition: all .15s;
}
.card:hover { border-color: #1a56db; background: #f0f5ff; transform: translateX(3px); }
.card.pp { border-color: #1a56db; }
.card img { height: 36px; flex-shrink: 0; }
.card-icon { font-size: 28px; flex-shrink: 0; width: 40px; text-align: center; }
.card-info { flex: 1; }
.card-title { font-size: 14px; font-weight: bold; color: #222; }
.card-desc { font-size: 12px; color: #666; margin-top: 3px; }
.badge { background: #1a56db; color: #fff; border-radius: 4px; padding: 3px 8px; font-size: 11px; font-weight: bold; white-space: nowrap; }
.divider { margin: 14px 0 10px; border: none; border-top: 2px dashed #ddd; }
.section-label { font-size: 11px; color: #999; text-transform: uppercase; font-weight: bold; margin-bottom: 8px; }
</style>
</head>
<body>
<div class="header">🖨️ Selecionar layout de impressão</div>
<div class="container">

<?php if ($tem_pp): ?>
<div class="section-label">PagoraPay</div>
<?php if (count($boletos_pp) === 1): ?>
<div class="card pp" onclick="window.location='/admin/addons/pagorapay/boleto_print.php?titulo_id=<?= $boletos_pp[0] ?>'">
<?php else: ?>
<div class="card pp" onclick="abrirMultiplosPP()">
<?php endif; ?>
  <img src="/admin/addons/pagorapay/logo_boleto.png" alt="PagoraPay" onerror="this.style.display='none'">
  <div class="card-info">
    <div class="card-title">Boleto PagoraPay + PIX</div>
    <div class="card-desc">Código de barras PagoraPay, QR Code PIX e logo — <?= count($boletos_pp) ?> título(s)</div>
  </div>
  <div class="badge">⚡ Recomendado</div>
</div>
<hr class="divider">
<div class="section-label">Outros layouts MKAuth</div>
<?php endif; ?>

<form id="mk-form" method="POST" action="/admin/imprimir_boletos.hhvm?login=<?= htmlspecialchars($login) ?>&imp=detcli" style="display:none">
<?php foreach ($titulo_ids as $id): ?>
  <input type="hidden" name="titulo[]" value="<?= $id ?>">
<?php endforeach; ?>
</form>

<div id="mk-layouts">
  <div style="text-align:center;padding:30px;color:#999;">⏳ Carregando layouts...</div>
</div>

<script>
(function() {
  var form = document.getElementById('mk-form');
  var fd = new FormData(form);
  fetch(form.action, { method: 'POST', body: fd, credentials: 'same-origin' })
    .then(function(r) { return r.text(); })
    .then(function(html) {
      var parser = new DOMParser();
      var doc = parser.parseFromString(html, 'text/html');
      var container = document.getElementById('mk-layouts');
      container.innerHTML = '';

      // Captura os cards de layout (divs clicáveis) da página do MKAuth
      var items = doc.querySelectorAll('div[onclick], a[onclick], a[href*="boleto"]');
      var added = 0;

      // Tenta pegar os itens de layout da página imprimir_boletos
      var allLinks = Array.from(doc.querySelectorAll('a[href]'));
      allLinks.forEach(function(a) {
        var href = a.getAttribute('href') || '';
        var text = a.textContent.trim();
        if (!href || href === '#' || !text || text.length < 3) return;
        if (href.includes('javascript:') || href.includes('login=')) return;

        var card = document.createElement('div');
        card.className = 'card';
        card.innerHTML = '<div class="card-icon">📄</div><div class="card-info"><div class="card-title">' +
          text.replace(/</g,'&lt;') + '</div></div>';
        // Corrige path relativo para /admin/
        var url = href;
        if (!url.startsWith('/') && !url.startsWith('http')) url = '/admin/' + url;
        var ids = <?= json_encode($titulo_ids) ?>;
        var proxy = '/admin/addons/pagorapay/boleto_layout_proxy.php?url=' + encodeURIComponent(url)
          + ids.map(function(id){ return '&titulo[]=' + id; }).join('');
        card.onclick = (function(p){ return function(){ window.location = p; }; })(proxy);
        container.appendChild(card);
        added++;
      });

      if (added === 0) {
        // Fallback: iframe com a página original
        container.innerHTML = '<iframe id="mk-iframe" style="width:100%;height:500px;border:1px solid #ddd;border-radius:6px;"></iframe>';
        var blob = new Blob([html], {type:'text/html'});
        document.getElementById('mk-iframe').src = URL.createObjectURL(blob);
      }
    })
    .catch(function() {
      // Fallback: abre a página original em nova aba
      document.getElementById('mk-layouts').innerHTML =
        '<div class="card" onclick="document.getElementById(\'mk-form\').target=\'_blank\';document.getElementById(\'mk-form\').submit();">' +
        '<div class="card-icon">📄</div><div class="card-info"><div class="card-title">Ver layouts MKAuth</div></div></div>';
    });
})();

function abrirMultiplosPP() {
  var ids = [<?= implode(',', $boletos_pp) ?>];
  ids.forEach(function(id, i) {
    setTimeout(function() {
      window.open('/admin/addons/pagorapay/boleto_print.php?titulo_id=' + id, '_blank');
    }, i * 300);
  });
}
</script>
</div>
</body>
</html>
