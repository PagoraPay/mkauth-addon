// Addon PagoraPay — MKAuth 22+

// ── MODAL INTERNO ─────────────────────────────────────────────────────────────
(function criarModal() {
  function injetarModal() {
    if (document.getElementById('pp-modal')) return;

    const style = document.createElement('style');
    style.textContent = `
      #pp-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:99998; }
      #pp-overlay.ativo { display:flex; align-items:flex-start; justify-content:center; padding-top:54px; }
      #pp-panel {
        background:#fff; border-radius:8px; box-shadow:0 8px 32px rgba(0,0,0,.25);
        width:96%; max-width:1100px; height:85vh; display:flex; flex-direction:column;
        overflow:hidden; position:relative;
      }
      #pp-topbar {
        background:#2c3e50; color:#fff; display:flex; align-items:center;
        padding:10px 16px; gap:12px; flex-shrink:0;
      }
      #pp-topbar span { font-weight:700; font-size:.95rem; flex:1; }
      #pp-topbar button {
        background:rgba(255,255,255,.15); border:none; color:#fff; border-radius:4px;
        padding:4px 12px; cursor:pointer; font-size:.85rem;
      }
      #pp-topbar button:hover { background:rgba(255,255,255,.3); }
      #pp-frame { flex:1; border:none; width:100%; }
      #pp-loading {
        position:absolute; inset:40px 0 0 0; display:flex; align-items:center;
        justify-content:center; font-size:1rem; color:#888; background:#f4f6f8;
      }
    `;
    document.head.appendChild(style);

    const overlay = document.createElement('div');
    overlay.id = 'pp-overlay';
    overlay.innerHTML = `
      <div id="pp-panel">
        <div id="pp-topbar">
          <span>💳 PagoraPay — Boleto &amp; PIX</span>
          <button onclick="ppFechar()">✕ Fechar</button>
        </div>
        <div id="pp-loading">⏳ Carregando...</div>
        <iframe id="pp-frame" src="" onload="document.getElementById('pp-loading').style.display='none'"></iframe>
      </div>
    `;
    document.body.appendChild(overlay);

    // Fecha ao clicar fora
    overlay.addEventListener('click', function(e) {
      if (e.target === overlay) ppFechar();
    });
    // Fecha com ESC
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape') ppFechar();
    });
  }

  window.ppAbrir = function(url) {
    injetarModal();
    const overlay = document.getElementById('pp-overlay');
    const frame   = document.getElementById('pp-frame');
    const loading = document.getElementById('pp-loading');
    loading.style.display = 'flex';
    frame.src = url || '/admin/addons/pagorapay/index.php';
    overlay.classList.add('ativo');
    document.body.style.overflow = 'hidden';
  };

  window.ppFechar = function() {
    const overlay = document.getElementById('pp-overlay');
    if (overlay) overlay.classList.remove('ativo');
    document.body.style.overflow = '';
  };
})();

// ── MENU PROVEDOR ─────────────────────────────────────────────────────────────
(function adicionarMenu() {
  function tryAdd() {
    // Método 1: API do MKAuth
    try {
      if (typeof app_menu_provedor !== 'undefined' && app_menu_provedor.itens2) {
        const existe = app_menu_provedor.itens2.some(i => i.href && i.href.includes('pagorapay'));
        if (!existe) app_menu_provedor.itens2.push({
          label: '💳 PagoraPay Boleto',
          href:  'javascript:ppAbrir()',
          icon:  'fa-credit-card'
        });
      }
    } catch(e) {}

    try {
      if (typeof add_menu !== 'undefined' && add_menu.provedor) {
        add_menu.provedor({ label: '💳 PagoraPay Boleto', href: 'javascript:ppAbrir()' });
      }
    } catch(e) {}

    // Método 2: intercepta link já existente no menu
    document.querySelectorAll('a').forEach(function(a) {
      if (a.href && a.href.includes('addons/pagorapay/index.php') && !a.dataset.ppMenu) {
        a.dataset.ppMenu = '1';
        a.addEventListener('click', function(e) {
          e.preventDefault();
          ppAbrir('/admin/addons/pagorapay/index.php');
        });
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', tryAdd);
  } else {
    tryAdd();
    setTimeout(tryAdd, 800);
    setTimeout(tryAdd, 2000);
  }
  new MutationObserver(tryAdd).observe(document.body, { childList: true, subtree: true });
})();

// ── BOTÃO NA PÁGINA DE CONTAS ─────────────────────────────────────────────────
(function injetarBotaoContas() {
  if (!window.location.href.includes('/contas')) return;

  function adicionarBotao() {
    document.querySelectorAll('td, a').forEach(function(el) {
      if (el.textContent.trim() === 'PagoraPay' && !el.dataset.ppBtn) {
        el.dataset.ppBtn = '1';

        const btn = document.createElement('a');
        btn.href = 'javascript:void(0)';
        btn.innerHTML = '&nbsp;⚙️ Configurar&nbsp;';
        btn.style.cssText = 'display:inline-block;margin-left:8px;padding:2px 10px;background:#2980b9;color:#fff;border-radius:4px;font-size:.82rem;font-weight:700;text-decoration:none;cursor:pointer;';
        btn.addEventListener('click', () => ppAbrir('/admin/addons/pagorapay/index.php?action=config'));
        el.parentNode?.appendChild(btn);

        const btn2 = document.createElement('a');
        btn2.href = 'javascript:void(0)';
        btn2.innerHTML = '&nbsp;💳 Cobranças&nbsp;';
        btn2.style.cssText = 'display:inline-block;margin-left:4px;padding:2px 10px;background:#27ae60;color:#fff;border-radius:4px;font-size:.82rem;font-weight:700;text-decoration:none;cursor:pointer;';
        btn2.addEventListener('click', () => ppAbrir('/admin/addons/pagorapay/index.php'));
        el.parentNode?.appendChild(btn2);
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', adicionarBotao);
  } else {
    adicionarBotao();
  }
  new MutationObserver(adicionarBotao).observe(document.body, { childList: true, subtree: true });
})();

// ── DROPDOWN DE TIPO DE CONTA ─────────────────────────────────────────────────
(function injetarNoDropdown() {
  if (!window.location.href.includes('contas_ins') && !window.location.href.includes('contas_alt')) return;

  function adicionarOpcao() {
    document.querySelectorAll('select').forEach(function(sel) {
      const temBoleto = Array.from(sel.options).some(o => o.text.includes('BOLETO PROPRIO'));
      if (!temBoleto || sel.dataset.ppAdded) return;
      sel.dataset.ppAdded = '1';

      sel.querySelectorAll('optgroup').forEach(g => { if (g.label === 'PAGORAPAY') g.remove(); });

      const group = document.createElement('optgroup');
      group.label = 'PAGORAPAY';
      const opt = document.createElement('option');
      opt.value = 'pagorapay';
      opt.text  = 'PAGORAPAY BOLETO & PIX';
      group.appendChild(opt);

      // Insere após FINTECH
      let fintechGroup = null;
      sel.querySelectorAll('optgroup').forEach(g => { if (g.label === 'FINTECH') fintechGroup = g; });
      if (fintechGroup) fintechGroup.parentNode.insertBefore(group, fintechGroup.nextSibling);
      else sel.appendChild(group);

      sel.addEventListener('change', function() {
        if (this.value === 'pagorapay') {
          const nome = document.querySelector('input[name="nome"]');
          if (nome && !nome.value) nome.value = 'PagoraPay';
          setTimeout(() => {
            if (confirm('A conta PagoraPay é configurada pelo addon. Abrir configurações?')) {
              ppAbrir('/admin/addons/pagorapay/index.php?action=config');
            }
          }, 100);
        }
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', adicionarOpcao);
  } else {
    adicionarOpcao();
  }
  new MutationObserver(adicionarOpcao).observe(document.body, { childList: true, subtree: true });
})();

// ── BOTÃO PAGORAPAY NA TELA DO CLIENTE ───────────────────────────────────────
(function injetarBotaoCliente() {
  if (!window.location.href.includes('cliente_det')) return;

  const uuidCliente = new URLSearchParams(window.location.search).get('uuid') || '';

  function extrairId(href) {
    if (!href) return null;
    let m;
    m = href.match(/[?&]titulo=(\d+)/);    if (m) return m[1];
    m = href.match(/[?&]id=(\d+)/);        if (m) return m[1];
    m = href.match(/[?&]titulo_id=(\d+)/); if (m) return m[1];
    return null;
  }

  function adicionarBotoes() {
    document.querySelectorAll('a').forEach(function(link) {
      if (link.dataset.ppInjetado) return;
      const texto = (link.textContent || '').trim();
      const href  = link.getAttribute('href') || '';
      if (texto !== 'Boleto' && !(href.includes('boleto') && !href.includes('pagorapay'))) return;

      link.dataset.ppInjetado = '1';
      const tituloId = extrairId(href);

      const btn = document.createElement('a');
      btn.innerHTML = '&nbsp;💳 PagoraPay&nbsp;';
      btn.style.cssText = 'display:inline-block;margin-left:4px;padding:1px 8px;background:#27ae60;color:#fff;border-radius:4px;font-size:.82rem;font-weight:700;text-decoration:none;cursor:pointer;vertical-align:middle;line-height:1.6';
      btn.title = 'Gerar / Ver cobrança PagoraPay';

      let url = '/admin/addons/pagorapay/index.php?action=novo';
      if (tituloId && uuidCliente) {
        url = '/admin/addons/pagorapay/boleto_print.php?titulo_id=' + tituloId + '&uuid=' + encodeURIComponent(uuidCliente);
      }

      btn.addEventListener('click', function(e) {
        e.preventDefault();
        ppAbrir(url);
      });

      link.parentNode.insertBefore(btn, link.nextSibling);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', adicionarBotoes);
  } else {
    adicionarBotoes();
  }
  new MutationObserver(adicionarBotoes).observe(document.body, { childList: true, subtree: true });
})();

// ── INTERCEPTA CLIQUE NO BOLETO ORIGINAL ─────────────────────────────────────
(function interceptarBoleto() {
  if (!window.location.href.includes('cliente_det')) return;

  const uuidCliente = new URLSearchParams(window.location.search).get('uuid') || '';

  function extrairId(href) {
    if (!href) return null;
    let m;
    m = href.match(/[?&]titulo=(\d+)/);    if (m) return m[1];
    m = href.match(/[?&]id=(\d+)/);        if (m) return m[1];
    return null;
  }

  function interceptar() {
    document.querySelectorAll('a').forEach(function(link) {
      if (link.dataset.ppIntercept) return;
      const texto = (link.textContent || '').trim();
      const href  = link.getAttribute('href') || '';
      if (texto !== 'Boleto' || !href.includes('boleto')) return;

      link.dataset.ppIntercept = '1';
      link.onclick = null;
      link.removeAttribute('onclick');
      link.href = 'javascript:void(0)';
      const tituloId = extrairId(href);
      if (!tituloId || !uuidCliente) return;

      link.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopImmediatePropagation();
        e.stopPropagation();
        // Verifica se existe boleto PagoraPay para este título
        fetch('/admin/addons/pagorapay/check_boleto.php?titulo_id=' + tituloId)
          .then(r => r.json())
          .then(data => {
            if (data.existe) {
              // Tem boleto PagoraPay — abre no modal
              ppAbrir('/admin/addons/pagorapay/boleto_print.php?titulo_id=' + tituloId + '&uuid=' + encodeURIComponent(uuidCliente));
            } else {
              // Não tem — abre o boleto original do MKAuth
              window.open(href, '_blank');
            }
          })
          .catch(() => window.open(href, '_blank'));
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', interceptar);
  } else {
    interceptar();
  }
  new MutationObserver(interceptar).observe(document.body, { childList: true, subtree: true });
})();

// ── Intercepta impressão de carnê ──────────────────────────────────────
(function interceptarCarne() {
  function tryIntercept() {
    // Intercepta botão imprimir carnê (ícone impressora) e links diretos
    var seletores = [
      'a[href*="carne.hhvm"]',
      'a[href*="tipo=3folhas"]',
      'a[href*="imprimir_carnes"]',
      'a[href*="imp=car"]',
      'a[href*="carne="]'
    ].join(', ');

    document.querySelectorAll(seletores).forEach(function(link) {
      if (link.dataset.ppCarne) return;
      link.dataset.ppCarne = '1';
      // Remove onClick inline (dispara antes do addEventListener)
      link.removeAttribute('onclick');
      link.onclick = null;
      link.addEventListener('click', function(e) {
        const href = link.getAttribute('href') || '';

        // Tenta extrair codigo_carne de diferentes padrões de URL
        let codigoCarne = '';
        let m;
        m = href.match(/[?&]carne=([a-zA-Z0-9]+)/);     if (m) codigoCarne = m[1];
        m = href.match(/[?&]codigo=([a-zA-Z0-9]+)/);    if (!codigoCarne && m) codigoCarne = m[1];

        // Se não achou código direto, pode ser o botão geral — pega do contexto da página
        if (!codigoCarne) {
          const urlParams = new URLSearchParams(window.location.search);
          codigoCarne = urlParams.get('carne') || urlParams.get('codigo') || '';
        }

        if (!codigoCarne) return; // deixa comportamento original

        // Previne IMEDIATAMENTE (não pode ser async)
        e.preventDefault();
        e.stopImmediatePropagation();
        e.stopPropagation();

        fetch('/admin/addons/pagorapay/check_boleto.php?codigo_carne=' + codigoCarne)
          .then(r => r.json())
          .then(data => {
            if (data.existe) {
              ppAbrir('/admin/addons/pagorapay/carne_print.php?codigo_carne=' + codigoCarne);
            } else {
              window.open(href, '_blank');
            }
          })
          .catch(() => window.open(href, '_blank'));
      });
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', tryIntercept);
  } else {
    tryIntercept();
  }
  new MutationObserver(tryIntercept).observe(document.body, { childList: true, subtree: true });
})();

// ── Intercepta botão imprimir carnê (run_carne_imprimir) ─────────────────────
(function interceptarBotaoImprimirCarne() {
  function tryIntercept() {
    const btn = document.getElementById('run_carne_imprimir');
    if (!btn || btn.dataset.ppCarneBtn) return;
    btn.dataset.ppCarneBtn = '1';

    // Remove handlers jQuery existentes e adiciona o nosso
    if (typeof jQuery !== 'undefined') {
      jQuery('#run_carne_imprimir').off('click');
    }

    btn.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopImmediatePropagation();
      e.stopPropagation();

      // Pega o código do carnê do form_carne
      const form = document.getElementById('form_carne');
      let codigoCarne = '';
      if (form) {
        const inputs = form.querySelectorAll('input[name="carne"], input[name="codigo_carne"]');
        inputs.forEach(i => { if (i.value) codigoCarne = i.value; });
        // Tenta também checkboxes marcados
        if (!codigoCarne) {
          const checked = form.querySelectorAll('input[type="checkbox"]:checked');
          checked.forEach(i => { if (i.value && !codigoCarne) codigoCarne = i.value; });
        }
      }

      if (!codigoCarne) {
        // Sem código — deixa o MKAuth agir normalmente
        if (typeof jQuery !== 'undefined') {
          jQuery('#run_carne_imprimir').off('click');
          btn.dataset.ppCarneBtn = '';
        }
        btn.click();
        return;
      }

      fetch('/admin/addons/pagorapay/check_boleto.php?codigo_carne=' + codigoCarne)
        .then(r => r.json())
        .then(data => {
          if (data.existe) {
            ppAbrir('/admin/addons/pagorapay/carne_print.php?codigo_carne=' + codigoCarne);
          } else {
            // Sem boleto PagoraPay — executa ação original do MKAuth
            jQuery('#form_carne').attr('action', 'imprimir_carnes.hhvm?imp=car');
            jQuery('#form_carne').attr('target', 'imprimir_carnes');
            fabrewin(800, 600, 'imprimir_carnes');
            jQuery('#form_carne').submit();
          }
        })
        .catch(() => {
          jQuery('#form_carne').attr('action', 'imprimir_carnes.hhvm?imp=car');
          jQuery('#form_carne').attr('target', 'imprimir_carnes');
          fabrewin(800, 600, 'imprimir_carnes');
          jQuery('#form_carne').submit();
        });
    }, true); // useCapture=true para pegar antes do jQuery
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', tryIntercept);
  } else {
    tryIntercept();
    setTimeout(tryIntercept, 500);
    setTimeout(tryIntercept, 1500);
  }
  new MutationObserver(tryIntercept).observe(document.body, { childList: true, subtree: true });
})();

// ─── Intercepta botão "Imprimir títulos" (run_imprimir) ───────────────────────
(function interceptarImprimirTitulos() {
  function tryIntercept() {
    const btn = document.getElementById('run_imprimir');
    if (!btn || btn.dataset.ppImprime) return;
    btn.dataset.ppImprime = '1';

    btn.addEventListener('click', function(e) {
      e.preventDefault();
      e.stopPropagation();
      e.stopImmediatePropagation();

      const form = document.getElementById('form_combox');
      if (!form) return;

      // Pega títulos selecionados
      const checked = form.querySelectorAll('input[name="titulo[]"]:checked');
      const ids = Array.from(checked).map(i => i.value).filter(Boolean);

      if (ids.length === 0) {
        // Nenhum selecionado — deixa o MKAuth agir
        btn.dataset.ppImprime = '';
        btn.click();
        return;
      }

      // Pega login da URL atual
      const loginMatch = window.location.search.match(/uuid=([^&]+)/);
      const login = loginMatch ? loginMatch[1] : '';

      const params = ids.map(id => 'titulo[]=' + encodeURIComponent(id)).join('&')
        + '&login=' + encodeURIComponent(login);

      window.open('/admin/addons/pagorapay/boleto_imprimir_menu.php?' + params, 'boleto_imprimir_menu', 'width=960,height=700,scrollbars=yes,resizable=yes');
    }, true);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', tryIntercept);
  } else {
    tryIntercept();
    setTimeout(tryIntercept, 500);
    setTimeout(tryIntercept, 1500);
  }
  new MutationObserver(tryIntercept).observe(document.body, { childList: true, subtree: true });
})();
