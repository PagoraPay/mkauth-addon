<?php
/**
 * boleto_redirect.php
 * Resolve o UUID do cliente para ID numérico e redireciona para boleto.php
 */
require_once __DIR__ . '/config.php';

$titulo_id   = intval($_GET['titulo_id'] ?? 0);
$uuid_cliente = $LOADMYSQL->real_escape_string($_GET['uuid'] ?? '');

if (!$titulo_id || !$uuid_cliente) {
    die('<p style="color:red;font-family:Arial;padding:20px;">Parâmetros inválidos.</p>');
}

// Busca cliente_id numérico pelo uuid
$res = $LOADMYSQL->query("SELECT id FROM sis_cliente WHERE uuid_cliente='$uuid_cliente' LIMIT 1");
if (!$res || $res->num_rows === 0) {
    die('<p style="color:red;font-family:Arial;padding:20px;">Cliente não encontrado para este UUID.</p>');
}
$row = $res->fetch_assoc();
$cliente_id = intval($row['id']);

header("Location: /admin/addons/pagorapay/boleto.php?titulo_id=$titulo_id&cliente_id=$cliente_id");
exit;
