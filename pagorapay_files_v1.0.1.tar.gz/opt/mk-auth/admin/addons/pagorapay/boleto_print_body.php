if (!$res || $res->num_rows === 0) die('Título não encontrado.');
$p = $res->fetch_assoc();

function fmt_linha($raw) {
    $d = preg_replace('/\D/', '', $raw);
    if (strlen($d) === 47)
        return substr($d,0,5).'.'.substr($d,5,5).' '.substr($d,10,5).'.'.substr($d,15,6).' '.
               substr($d,21,5).'.'.substr($d,26,6).' '.substr($d,32,1).' '.substr($d,33,14);
    return $raw;
}

// Busca HTML nativo com cookies de sessão
$cookies = [];
foreach ($_COOKIE as $k => $v) $cookies[] = urlencode($k).'='.urlencode($v);
$ctx = stream_context_create(['http' => [
    'timeout'         => 15,
    'follow_location' => true,
    'header'          => 'Cookie: '.implode('; ', $cookies)."\r\n"
]]);
$html = @file_get_contents('http://127.0.0.1/boleto/boleto.hhvm?titulo='.$titulo_id.'&pp_bypass=1', false, $ctx);
if (!$html) die('<p style="padding:40px;color:red;">Erro ao carregar boleto.</p>');

// Corrige caminhos relativos
$base = 'http://172.31.255.2';
$html = preg_replace('/\bsrc="(?!http|data)([^"]+)"/i', 'src="'.$base.'/boleto/$1"', $html);

// Substitui linha digitável pelo código PagoraPay
if (!empty($p['linha_mk']) && !empty($p['pp_linha'])) {
    $fmt = fmt_linha($p['pp_linha']);
    $html = str_replace(htmlspecialchars($p['linha_mk']), htmlspecialchars($fmt), $html);
    $html = str_replace($p['linha_mk'], $fmt, $html);
}

// Remove "BOLETO PRÓPRIO"
$html = preg_replace('/\.bollogo_XXX\s*\{[^}]*\}/s', '.bollogo_XXX { height: 40px; }', $html);

// Logo PagoraPay na 1ª bollogo_XXX
$logo_path = __DIR__.'/logo_boleto.png';
if (file_exists($logo_path)) {
    $logo_b64 = base64_encode(file_get_contents($logo_path));
    $logo_img = '<img src="data:image/png;base64,'.$logo_b64.'" style="height:38px;max-width:140px;object-fit:contain;print-color-adjust:exact;-webkit-print-color-adjust:exact;" alt="PagoraPay">';
    $count_logo = 0;
    $html = preg_replace_callback(
        '/<div class="bollogo_XXX"><\/div>/',
        function($m) use ($logo_img, &$count_logo) {
            $count_logo++;
            return ($count_logo % 2 === 1)
                ? '<div class="bollogo_XXX">'.$logo_img.'</div>'
                : $m[0];
        },
        $html
    );
}

// Substitui QR placeholder pelo QR PIX real com label
if (!empty($p['pix_qrcode'])) {
    $qr = htmlspecialchars($p['pix_qrcode']);
    $qr_html = '<div style="text-align:center;display:inline-block;">'
        . '<img src="data:image/png;base64,'.$qr.'" width="150" height="150" style="display:block;" alt="QR PIX">'
        . '<span style="display:block;font-size:11px;font-weight:bold;color:#32a852;margin-top:3px;font-family:Arial,sans-serif;">&#9889; Pague com PIX</span>'
        . '</div>';
    $html = preg_replace(
        '/<img\s[^>]*src="data:image\/jpeg;base64,[^"]{100,}"[^>]*>/',
        $qr_html,
        $html
    );
}

// Barra de botões
$barra = '<style>
  @media print { .pp-noprint{display:none!important;} img{print-color-adjust:exact;-webkit-print-color-adjust:exact;} }
</style>
<div class="pp-noprint" style="background:#1a56db;color:#fff;padding:10px;text-align:center;position:sticky;top:0;z-index:9999;">
  <button onclick="window.print()" style="background:#fff;color:#1a56db;border:none;padding:8px 20px;border-radius:4px;font-size:13px;font-weight:bold;cursor:pointer;margin:0 5px;">&#128424; Imprimir Boleto</button>
  <button onclick="try{window.parent.ppFechar();}catch(e){}window.close();" style="background:#e53e3e;color:#fff;border:none;padding:8px 20px;border-radius:4px;font-size:13px;font-weight:bold;cursor:pointer;margin:0 5px;">&#10005; Fechar</button>
</div>';

$html = preg_replace('/<body([^>]*)>/i', '<body$1>'.$barra, $html, 1);
echo $html;
