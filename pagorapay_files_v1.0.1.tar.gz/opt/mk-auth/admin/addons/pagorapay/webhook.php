<?php
/**
 * webhook.php — Recebe confirmações da PagoraPay e atualiza o MKAuth
 * URL: https://seudominio.com/admin/addons/pagorapay/webhook.php?token=SEU_TOKEN
 */
require_once __DIR__ . '/config.php';

$log_file = __DIR__ . '/webhook_log.txt';
function wlog($msg) { global $log_file; file_put_contents($log_file, '[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n", FILE_APPEND | LOCK_EX); }

// ── Valida token ──────────────────────────────────────────────────────────────
$token = $_GET['token'] ?? '';
if (!pagorapay_validar_token($token)) {
    wlog("Token inválido: $token");
    http_response_code(401);
    exit('unauthorized');
}

$raw  = file_get_contents('php://input');
$data = json_decode($raw, true);
wlog("Recebido: $raw");

if (!$data) { http_response_code(200); exit('ok'); }

$evento     = strtoupper($data['evento'] ?? $data['event'] ?? '');
$id_externo = $data['id_externo'] ?? $data['dados']['id_externo'] ?? '';
$valor_pago = $data['valor']      ?? $data['dados']['valor']      ?? 0;

wlog("Evento: $evento | id_externo: $id_externo");

// Eventos suportados
$eventos_pagamento   = ['COBRANCA_PAGA', 'PAGAMENTO_CONFIRMADO', 'PAGO'];
$eventos_cancelamento = ['COBRANCA_CANCELADA', 'CANCELADA'];

if (!in_array($evento, array_merge($eventos_pagamento, $eventos_cancelamento))) {
    wlog("Evento '$evento' ignorado");
    http_response_code(200); exit('ok');
}

if (empty($id_externo)) {
    wlog("id_externo vazio");
    http_response_code(200); exit('ok');
}

// ── Busca boleto ──────────────────────────────────────────────────────────────
$ie_safe = $LOADMYSQL->real_escape_string($id_externo);
$res = $LOADMYSQL->query("SELECT * FROM pagorapay_boletos WHERE id_externo='$ie_safe' LIMIT 1");
if (!$res || $res->num_rows === 0) {
    wlog("Boleto não encontrado: $id_externo");
    http_response_code(200); exit('ok');
}
$boleto = $res->fetch_assoc();

// ── CANCELAMENTO ──────────────────────────────────────────────────────────────
if (in_array($evento, $eventos_cancelamento)) {
    if ($boleto['status'] === 'cancelado') {
        wlog("Boleto já cancelado: $id_externo");
        http_response_code(200); exit('ok');
    }

    $LOADMYSQL->query("UPDATE pagorapay_boletos SET status='cancelado', updated_at=NOW() WHERE id_externo='$ie_safe'");
    wlog("pagorapay_boletos marcado como cancelado: $id_externo");

    $titulo_id = intval($boleto['carne_id'] ?? 0);
    if ($titulo_id) {
        $ok = $LOADMYSQL->query("UPDATE sis_lanc SET deltitulo=1, datadel=NOW()
                                  WHERE id=$titulo_id AND status='aberto'");
        if ($ok && $LOADMYSQL->affected_rows > 0) {
            wlog("Título #$titulo_id cancelado no MKAuth via cancelamento PagoraPay");
            $desc_log = $LOADMYSQL->real_escape_string("PagoraPay: título #$titulo_id cancelado via gateway");
            $LOADMYSQL->query("INSERT INTO sis_logs (login, operacao, data) VALUES ('mk-bot', '$desc_log', NOW())");
        } else {
            wlog("Título #$titulo_id não encontrado ou já cancelado no MKAuth");
        }
    } else {
        wlog("carne_id vazio — sem título para cancelar no MKAuth");
    }

    http_response_code(200); exit('ok');
}

// ── PAGAMENTO ─────────────────────────────────────────────────────────────────
if ($boleto['status'] === 'pago') {
    wlog("Boleto já marcado como pago: $id_externo");
    http_response_code(200); exit('ok');
}

// 1. Atualiza status na tabela do addon
$LOADMYSQL->query("UPDATE pagorapay_boletos SET status='pago', updated_at=NOW() WHERE id_externo='$ie_safe'");
wlog("pagorapay_boletos atualizado para pago");

// 2. Quita o título no MKAuth
$titulo_id = intval($boleto['carne_id'] ?? 0);
if ($titulo_id) {
    $valpago = floatval($valor_pago ?: $boleto['valor']);
    $datapag = date('Y-m-d H:i:s');

    $ok = $LOADMYSQL->query("UPDATE sis_lanc SET
        status   = 'pago',
        datapag  = '$datapag',
        valorpag = '$valpago',
        formapag = 'PagoraPay PIX/Boleto'
        WHERE id=$titulo_id AND status='aberto'");

    if ($ok && $LOADMYSQL->affected_rows > 0) {
        wlog("Título #$titulo_id quitado no MKAuth! Valor: R$ $valpago");

        // 3. Atualiza contadores do cliente (só decrementa vencidos se estava vencido)
        $cliente_id = intval($boleto['cliente_id']);
        $res_lanc = $LOADMYSQL->query("SELECT datavenc FROM sis_lanc WHERE id=$titulo_id LIMIT 1");
        $lanc_row = $res_lanc ? $res_lanc->fetch_assoc() : null;
        $estava_vencido = $lanc_row && !empty($lanc_row['datavenc']) && $lanc_row['datavenc'] < date('Y-m-d');
        $dec_vencidos   = $estava_vencido ? ', tit_vencidos = GREATEST(0, COALESCE(tit_vencidos,0) - 1)' : '';
        $LOADMYSQL->query("UPDATE sis_cliente SET
            tit_abertos = GREATEST(0, COALESCE(tit_abertos,0) - 1)
            $dec_vencidos
            WHERE id=$cliente_id");

        // 4. Log MKAuth
        $desc_log = $LOADMYSQL->real_escape_string("PagoraPay: título #$titulo_id pago via PIX/Boleto - R$ $valpago");
        $LOADMYSQL->query("INSERT INTO sis_logs (login, operacao, data) VALUES ('mk-bot', '$desc_log', NOW())");

        wlog("Cliente #$cliente_id atualizado");
    } else {
        wlog("Título #$titulo_id não encontrado ou já pago no MKAuth");
    }
} else {
    wlog("carne_id vazio — sem título para quitar");
}

http_response_code(200);
echo 'ok';
